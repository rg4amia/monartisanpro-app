<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    HomeController,
    AboutController,
    ProjectController,
    NewsController,
    ContactController,
    DistrictController,
    InstitutionController,
    GouvernementController,
    RégionController,
    DashboardController,
    ProfileController,
    UserManagementController,
    ReportController,
    TresGrandeEntrepriseController,
    GrandeEntrepriseController,
    MoyenneEntrepriseController,
    PetiteEntrepriseController,
    GroupementProfessionnelController,
    AssociationProfessionnelController,
    AmbassadeController
};

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [AboutController::class, 'index'])->name('about');

Route::prefix('projects')->name('projects.')->group(function () {
    Route::get('/', [ProjectController::class, 'index']);
    Route::get('/instutions', [ProjectController::class, 'institutions'])->name('institutions');
    Route::get('/ministeres', [ProjectController::class, 'ministeres'])->name('ministeres');
    Route::get('/districts', [ProjectController::class, 'districts'])->name('districts');
    Route::get('/communes', [ProjectController::class, 'communes'])->name('communes');
    Route::get('/conseils-regionales', [ProjectController::class, 'conseilRegionale'])->name('conseils-regionales');
    Route::get('/centrale-syndicales', [ProjectController::class, 'centraleSyndicales'])->name('centrale-syndicales');

    Route::get('/ambassades',[AmbassadeController::class, 'index'])->name('ambassades');

    // Secteur Privé Routes
    Route::get('/tres-grande-entreprise', [TresGrandeEntrepriseController::class, 'index'])->name('tres-grande-entreprise');
    Route::get('/tres-grande-entreprise/{entreprise}', [TresGrandeEntrepriseController::class, 'show'])->name('tres-grande-entreprise.show');

    Route::get('/grande-entreprise', [GrandeEntrepriseController::class, 'index'])->name('grande-entreprise');
    Route::get('/grande-entreprise/{entreprise}', [GrandeEntrepriseController::class, 'show'])->name('grande-entreprise.show');

    Route::get('/moyenne-entreprise', [MoyenneEntrepriseController::class, 'index'])->name('moyenne-entreprise');
    Route::get('/moyenne-entreprise/{entreprise}', [MoyenneEntrepriseController::class, 'show'])->name('moyenne-entreprise.show');

    Route::get('/petite-entreprise', [PetiteEntrepriseController::class, 'index'])->name('petite-entreprise');
    Route::get('/petite-entreprise/{entreprise}', [PetiteEntrepriseController::class, 'show'])->name('petite-entreprise.show');

    Route::get('/groupements-professionnels', [GroupementProfessionnelController::class, 'index'])->name('groupements-professionnels');
    Route::get('/groupements-professionnels/{groupement}', [GroupementProfessionnelController::class, 'show'])->name('groupements-professionnels.show');

    Route::get('/associations-professionnels', [AssociationProfessionnelController::class, 'index'])->name('associations-professionnels');
    Route::get('/associations-professionnels/{association}', [AssociationProfessionnelController::class, 'show'])->name('associations-professionnels.show');
});

Route::prefix('news')->group(function () {
    Route::get('/', [NewsController::class, 'index'])->name('news');
    Route::get('/details/{slug}', [NewsController::class, 'show'])->name('news.show');
});

Route::get('/contact', [ContactController::class, 'index'])->name('contact');

Route::middleware(['auth'])->name( 'back-office.')->group(function () {
    Route::resources([
        'districts' => DistrictController::class,
        'institutions' => InstitutionController::class,
        'gouvernements' => GouvernementController::class,
        'regions' => RégionController::class,
    ]);

    // Dashboard admin
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // Profil utilisateur
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Gestion des utilisateurs (pour les administrateurs)
    Route::middleware(['can:manage-users'])->group(function () {
        Route::resource('users', UserManagementController::class);
    });

    // Statistiques et rapports
    Route::prefix('reports')->group(function () {
        Route::get('/', [ReportController::class, 'index'])->name('reports.index');
        Route::get('/districts', [ReportController::class, 'districts'])->name('reports.districts');
        Route::get('/institutions', [ReportController::class, 'institutions'])->name('reports.institutions');
    });
});
