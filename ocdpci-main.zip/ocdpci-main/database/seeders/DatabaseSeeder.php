<?php

namespace Database\Seeders;

use App\Models\User;
use Database\Seeders\NewsSeeder;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        /* User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]); */

        $this->call([
            //NewsSeeder::class,
            AmbassadeSeeder::class,
            AssociationProfessionnelleSeeder::class,
            CommuneSeeder::class,
            DistrictsSeeder::class,
            GrandEntrepriseSeeder::class,
            GroupementProfessionnelSeeder::class,
            InstitutionSeeder::class,
            MoyenneEntrepriseSeeder::class,
            PetitEntrepriseSeeder::class,
            RegionSeeder::class,
            SyndicatSeed::class,
            TresGrandEntrepriseSeeder::class,
            GouvernementSeeder::class,
        ]);
    }
}
