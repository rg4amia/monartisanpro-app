<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AssociationProfessionnelleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $associations = [
            ['name' => 'ANESPLACI', 'slug' => Str::slug('ANESPLACI'), 'website' => null],
            ['name' => 'APCCI', 'slug' => Str::slug('APCCI'), 'website' => null],
            ['name' => 'APCI', 'slug' => Str::slug('APCI'), 'website' => 'apci-btp.com'],
            ['name' => 'CCI FRANCE COTE D\'IVOIRE', 'slug' => Str::slug('CCI FRANCE COTE D\'IVOIRE'), 'website' => 'www.ccilci.org'],
            ['name' => 'CHAMBRE DES NOTAIRES DE CÔTE D\'IVOIRE', 'slug' => Str::slug('CHAMBRE DES NOTAIRES DE CÔTE D\'IVOIRE'), 'website' => null],
            ['name' => 'CSRP-CI', 'slug' => Str::slug('CSRP-CI'), 'website' => 'www.csrs.ch/fr'],
            ['name' => 'FENAPEPS-CI', 'slug' => Str::slug('FENAPEPS-CI'), 'website' => 'fenapepsci.com'],
            ['name' => 'FENEPLACI', 'slug' => Str::slug('FENEPLACI'), 'website' => null],
            ['name' => 'GEPEX', 'slug' => Str::slug('GEPEX'), 'website' => 'guepex.app'],
            ['name' => 'GNI', 'slug' => Str::slug('GNI'), 'website' => null],
            ['name' => 'GOTIC', 'slug' => Str::slug('GOTIC'), 'website' => 'www.gotic.ci'],
            ['name' => 'MPME', 'slug' => Str::slug('MPME'), 'website' => 'mpme-ci.org '],
            ['name' => 'OBAMCI', 'slug' => Str::slug('OBAMCI'), 'website' => null],
            ['name' => 'OCAB', 'slug' => Str::slug('OCAB'), 'website' => null],
            ['name' => 'UNEMAF', 'slug' => Str::slug('UNEMAF'), 'website' => 'www.unemaf.org'],
            ['name' => 'UPESUP', 'slug' => Str::slug('UPESUP'), 'website' => 'www.upesup.ci'],
        ];

        foreach ($associations as $association) {
            DB::table('association_professionnelles')->insert($association);
        }
    }
}
