<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class SyndicatSeed extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        $syndicats = [
            [
                'name' => 'Union Générale des Travailleurs de Côte d’Ivoire (UGTCI)',
                'slug' => 'union-générale-des-travailleurs-de-côte-d’ivoire-(ugtci)',
                'description' => 'Union Générale des Travailleurs de Côte d’Ivoire (UGTCI)',
                'logo' => null,
                'website' => 'ugtci.org/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Confédération des Syndicats Libres (CSL/Dignité)',
                'slug' => 'confédération-des-syndicats-libres-(csl/dignité)',
                'description' => 'Confédération des Syndicats Libres (CSL/Dignité)',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Fédération des Syndicats Autonomes de Côte d’Ivoire (FESACI)',
                'slug' => 'fédération-des-syndicats-autonomes-de-côte-d’ivoire-(fesaci)',
                'description' => 'Fédération des Syndicats Autonomes de Côte d’Ivoire (FESACI)',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Humanisme',
                'slug' => 'humanisme',
                'description' => 'Humanisme',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Union Nationale des Travailleurs de Côte d’Ivoire (UNATRCI)',
                'slug' => 'union-nationale-des-travailleurs-de-côte-d’ivoire-(unatrici)',
                'description' => 'Union Nationale des Travailleurs de Côte d’Ivoire (UNATRCI)',
                'logo' => null,
                'website' => 'unatrci.org/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
        ];

        DB::table('syndicats')->insert($syndicats);
    }
}
