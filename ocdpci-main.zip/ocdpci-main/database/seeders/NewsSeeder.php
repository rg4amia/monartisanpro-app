<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;
use App\Models\User;
use App\Models\News;
use Carbon\Carbon;

class NewsSeeder extends Seeder
{
 /**
  * Run the database seeds.
  */
 public function run(): void
 {
  // Clear existing news entries
  DB::table('news')->truncate();

  // Create Faker instance
  $faker = Faker::create();

  // Get existing user IDs to use as authors
  $userIds = User::pluck('id')->toArray();

  // Create multiple news entries
  $newsEntries = [];

  for ($i = 0; $i < 20; $i++) {
   $newsEntries[] = [
    'title' => $faker->sentence(6),
    'content' => $faker->paragraphs(3, true),
    'image' => $faker->optional(0.7)->imageUrl(640, 480, 'news'),
    'publication_date' => $faker->dateTimeBetween('-1 year', 'now'),
    'author_id' => $faker->randomElement($userIds),
    'comment_count' => $faker->numberBetween(0, 50),
    'created_at' => Carbon::now(),
    'updated_at' => Carbon::now(),
   ];
  }

  // Insert news entries
  News::insert($newsEntries);
 }
}
