<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TresGrandEntrepriseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $companies = [
            ['name' => 'AIRONE CI', 'website' => 'www.airone-seafood.com', 'slug' => Str::slug('AIRONE CI')],
            ['name' => 'MOOV AFRICA', 'website' => 'www.moov-africa.com', 'slug' => Str::slug('MOOV AFRICA')],
            ['name' => 'BERNABE', 'website' => 'www.bernabeafrique.com', 'slug' => Str::slug('BERNABE')],
            ['name' => 'BOUYGUES ENERGIES ET SERVICES', 'website' => 'www.bouygues.com', 'slug' => Str::slug('BOUYGUES ENERGIES ET SERVICES')],
            ['name' => 'BACI', 'website' => 'www.banqueatlantique.net', 'slug' => Str::slug('BACI')],
            ['name' => 'BTL CI', 'website' => 'www.bollore-transport-logistics.com', 'slug' => Str::slug('BTL CI')],
            ['name' => 'BMI', 'website' => 'www.brandonmcain.com', 'slug' => Str::slug('BMI')],
            ['name' => 'CIE', 'website' => 'www.cie.ci', 'slug' => Str::slug('CIE')],
            ['name' => 'C+CI', 'website' => 'www.canalplus-afrique.com/ci', 'slug' => Str::slug('C+CI')],
            ['name' => 'COIC', 'website' => null, 'slug' => Str::slug('COIC')],
            ['name' => 'CI-ENERGIES', 'website' => 'www.cinergies.com', 'slug' => Str::slug('CI-ENERGIES')],
            ['name' => 'CROWB SIEM', 'website' => 'www.eviosys.com', 'slug' => Str::slug('CROWB SIEM')],
            ['name' => 'IPS CNPS', 'website' => 'www.cnps.ci', 'slug' => Str::slug('IPS CNPS')],
            ['name' => 'IVOIRE WIN', 'website' => 'www.ivoirewin.com', 'slug' => Str::slug('IVOIRE WIN')],
            ['name' => 'LBTP', 'website' => 'www.lbtp.org', 'slug' => Str::slug('LBTP')],
            ['name' => 'MANSA BANK', 'website' => 'www.mansabank.com', 'slug' => Str::slug('MANSA BANK')],
            ['name' => 'NSIA BANQUE', 'website' => 'www.nsiabanque.ci', 'slug' => Str::slug('NSIA BANQUE')],
            ['name' => 'ORANGE CI', 'website' => 'www.orange.ci', 'slug' => Str::slug('ORANGE CI')],
            ['name' => 'PETRO IVOIRE SA', 'website' => 'www.petroivoire.com', 'slug' => Str::slug('PETRO IVOIRE SA')],
            ['name' => 'POLYCLINIQUE FARAH', 'website' => 'www.polycliniquefarah.com', 'slug' => Str::slug('POLYCLINIQUE FARAH')],
            ['name' => 'MATA HOLDING', 'website' => null, 'slug' => Str::slug('MATA HOLDING')],
            ['name' => 'SCB', 'website' => 'www.compagniefruitiere.fr', 'slug' => Str::slug('SCB')],
            ['name' => 'SDA RCI', 'website' => 'www.cfao-retail.com', 'slug' => Str::slug('SDA RCI')],
            ['name' => 'SODECI', 'website' => 'www.sodeci.ci', 'slug' => Str::slug('SODECI')],
            ['name' => 'GESTOCI', 'website' => 'www.gestoci.ci', 'slug' => Str::slug('GESTOCI')],
            ['name' => 'SG CI', 'website' => 'www.societegenerale.ci', 'slug' => Str::slug('SG CI')],
            ['name' => 'SOCIFAD', 'website' => 'www.socifad.com', 'slug' => Str::slug('SOCIFAD')],
            ['name' => 'SIB', 'website' => 'www.sib.ci', 'slug' => Str::slug('SIB')],
            ['name' => 'SIBM', 'website' => 'www.sibmci.com', 'slug' => Str::slug('SIBM')],
            ['name' => 'SIR', 'website' => 'www.sir.ci', 'slug' => Str::slug('SIR')],
            ['name' => 'PROSUMA', 'website' => 'www.groupeprosuma.ci', 'slug' => Str::slug('PROSUMA')],
            ['name' => 'SITAB', 'website' => 'www.imperial-tobacco.com', 'slug' => Str::slug('SITAB')],
            ['name' => 'SMB', 'website' => 'www.smbci.ci', 'slug' => Str::slug('SMB')],
            ['name' => 'TVA', 'website' => 'www.sea-invest.com', 'slug' => Str::slug('TVA')],
            ['name' => 'TMCI', 'website' => 'www.tractafrictmc-ci.com', 'slug' => Str::slug('TMCI')],
            ['name' => 'LABOREX CI', 'website' => 'www.ubipharm-cotedivoire.com', 'slug' => Str::slug('LABOREX CI')],
        ];

        DB::table('tres_grand_entreprises')->insert($companies);
    }
}
