<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class PetitEntrepriseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $businesses = [
            ['name' => 'CENTRE KINE MEDICAL', 'slug' => Str::slug('CENTRE KINE MEDICAL'), 'website' => 'www.centrekinemedical.com'],
            ['name' => 'CECI', 'slug' => Str::slug('CECI'), 'website' => null, 'email' => 'ceci@gottolding.ci.com'],
            ['name' => 'CILAGRI-CAJOU', 'slug' => Str::slug('CILAGRI-CAJOU'), 'website' => 'www.cilagri.com'],
            ['name' => 'EDITIONS EBURNIE', 'slug' => Str::slug('EDITIONS EBURNIE'), 'website' => 'www.editionseburnie.net'],
            ['name' => 'CFI', 'slug' => Str::slug('CFI'), 'website' => 'www.farandole.ci'],
            ['name' => 'ENERTEL', 'slug' => Str::slug('ENERTEL'), 'website' => 'www.enertel.ci'],
            ['name' => 'ES PARTNERS', 'slug' => Str::slug('ES PARTNERS'), 'website' => 'www.espartners.co'],
            ['name' => 'FEDEX', 'slug' => Str::slug('FEDEX'), 'website' => 'www.fedex.com'],
            ['name' => 'GOS CI', 'slug' => Str::slug('GOS CI'), 'website' => 'www.globalooh.net'],
            ['name' => 'GTA CI', 'slug' => Str::slug('GTA CI'), 'website' => 'www.grantthornton.ci'],
            ['name' => 'GOOD WILL', 'slug' => Str::slug('GOOD WILL'), 'website' => 'www.goodwillaudit.ci'],
            ['name' => 'IFG AFRIQUE', 'slug' => Str::slug('IFG AFRIQUE'), 'website' => 'www.ifgecutive.com/Afrique'],
            ['name' => 'MDE BUSINESS SCHOOL', 'slug' => Str::slug('MDE BUSINESS SCHOOL'), 'website' => 'www.mde.ci'],
            ['name' => 'INTELLIGENCE', 'slug' => Str::slug('INTELLIGENCE'), 'website' => 'www.mzkgroupe.info'],
            ['name' => 'KFP RCI', 'slug' => Str::slug('KFP RCI'), 'website' => 'www.keysfinance.com'],
            ['name' => 'IT2000 CATEL', 'slug' => Str::slug('IT2000 CATEL'), 'website' => null, 'email' => 'It2000cartel@gmail.com'],
            ['name' => 'IPS WA', 'slug' => Str::slug('IPS WA'), 'website' => 'www.ips.wa.org'],
            ['name' => 'KOFFI ET DIABATE GROUP', 'slug' => Str::slug('KOFFI ET DIABATE GROUP'), 'website' => 'wwwkoffi-diabate.com'],
            ['name' => 'LEB', 'slug' => Str::slug('LEB'), 'website' => 'www.leb-ci.com'],
            ['name' => 'FERA VIE', 'slug' => Str::slug('FERA VIE'), 'website' => 'www.feravie.com'],
            ['name' => 'METEA GROUPE SA', 'slug' => Str::slug('METEA GROUPE SA'), 'website' => 'www.meteaci.com'],
            ['name' => 'MCE', 'slug' => Str::slug('MCE'), 'website' => 'www.mce-afrique.net'],
            ['name' => 'LA ROSETTE SARL', 'slug' => Str::slug('LA ROSETTE SARL'), 'website' => 'www.larosettegroupe.com'],
            ['name' => 'MAYELIA', 'slug' => Str::slug('MAYELIA'), 'website' => 'www.mayelia.com'],
            ['name' => 'MAZARS CI', 'slug' => Str::slug('MAZARS CI'), 'website' => 'www.mazars.ci'],
            ['name' => 'MKC&F', 'slug' => Str::slug('MKC&F'), 'website' => 'www.mk-conseil.net'],
            ['name' => 'OPTIMUM INTERNATIONAL', 'slug' => Str::slug('OPTIMUM INTERNATIONAL'), 'website' => 'www.optiminternationalci.com'],
            ['name' => 'OLEA', 'slug' => Str::slug('OLEA'), 'website' => 'www.olea.africa'],
            ['name' => 'NUTRIVOIRE', 'slug' => Str::slug('NUTRIVOIRE'), 'website' => 'www.nutrivoire.net'],
            ['name' => 'PANESS CI', 'slug' => Str::slug('PANESS CI'), 'website' => 'www.panessconseils.com'],
            ['name' => 'PHARMACIE MAZUET', 'slug' => Str::slug('PHARMACIE MAZUET'), 'website' => null, 'email' => 'Cimazuet@aviso.ci'],
            ['name' => 'PHARMACIE DE YAMOUSSOUKRO', 'slug' => Str::slug('PHARMACIE DE YAMOUSSOUKRO'), 'website' => null, 'email' => 'pharmacie-agbassigyahoo.com'],
            ['name' => 'PIXAFRICA', 'slug' => Str::slug('PIXAFRICA'), 'website' => 'www.pixagrility.com'],
            ['name' => 'PIGIER CI', 'slug' => Str::slug('PIGIER CI'), 'website' => 'www.pigierci.com'],
            ['name' => 'PCM', 'slug' => Str::slug('PCM'), 'website' => 'wwwphoenixafricaholding.com'],
            ['name' => 'PKL SA', 'slug' => Str::slug('PKL SA'), 'website' => 'www.pkl-ci.com'],
            ['name' => 'QNA', 'slug' => Str::slug('QNA'), 'website' => 'www.atalian.com/www.atalan.ci'],
            ['name' => 'SAS', 'slug' => Str::slug('SAS'), 'website' => 'www.sas-gersons.com'],
            ['name' => 'SAAR', 'slug' => Str::slug('SAAR'), 'website' => 'www.saar.assurance.com'],
            ['name' => 'SODIPEX', 'slug' => Str::slug('SODIPEX'), 'website' => 'www.sodipex.net'],

            ['name' => 'WESTECH', 'slug' => Str::slug('WESTECH'), 'website' => 'www.westech.ci'],
            ['name' => 'VOODOO COMMUNICATION', 'slug' => Str::slug('VOODOO COMMUNICATION'), 'website' => 'www.voodoogroup.africa'],
            ['name' => 'TTI', 'slug' => Str::slug('TTI'), 'website' => 'www.tropicaltransit.ci'],
            ['name' => 'TBC', 'slug' => Str::slug('TBC'), 'website' => 'www.tbc.ci'],
            ['name' => 'PENDIS', 'slug' => Str::slug('PENDIS'), 'website' => 'www.pendis-ci.com'],
            ['name' => 'TCCEC', 'slug' => Str::slug('TCCEC'), 'website' => 'www.cocacola.ci'],
            ['name' => 'SOGEMCO', 'slug' => Str::slug('SOGEMCO'), 'website' => 'www.sogemcointer-ci.com'],
            ['name' => 'SONITRA', 'slug' => Str::slug('SONITRA'), 'website' => 'www.sonitra.com'],
            ['name' => 'SIMAT', 'slug' => Str::slug('SIMAT'), 'website' => 'www.simat-ci.com'],
            ['name' => 'SIPEL', 'slug' => Str::slug('SIPEL'), 'website' => 'www.sipel-sa.com'],
            ['name' => 'SEPT', 'slug' => Str::slug('SEPT'), 'website' => 'www.sept-ci.com'],
            ['name' => 'HUDSON', 'slug' => Str::slug('HUDSON'), 'website' => 'www.hudson-cie.net'],
            ['name' => 'SAS GERSONS', 'slug' => Str::slug('SAS GERSONS'), 'website' => 'www.sas-gersons.com'],
        ];

        foreach ($businesses as $business) {
            DB::table('petit_entreprises')->insert($business);
        }
    }
}
