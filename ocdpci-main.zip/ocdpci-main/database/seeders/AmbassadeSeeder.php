<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AmbassadeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ambassades = [
            // Représentations en Europe
            ['name' => 'Ambassade de Côte d\'Ivoire en France', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en France'), 'website' => 'http://www.france.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Royaume-Uni', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Royaume-Uni'), 'website' => 'http://www.grandebretagne.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Allemagne', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Allemagne'), 'website' => 'www.ambaci.de'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Belgique', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Belgique'), 'website' => 'http://www.belgique.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Italie', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Italie'), 'website' => 'http://www.italie.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Russie', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Russie'), 'website' => 'http://www.ambaci-russie.org/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Suisse', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Suisse'), 'website' => 'http://www.suisse.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Espagne', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Espagne'), 'website' => 'http://www.espagne.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Danemark', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Danemark'), 'website' => 'www.danemark.diplomatie.gouv.ci'],
            ['name' => 'Ambassade de Côte d\'Ivoire auprès de l\'UNESCO', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire auprès de l\'UNESCO'), 'website' => 'http://www.unesco.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire auprès de l\'Union Européenne', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire auprès de l\'Union Européenne'), 'website' => 'http://www.belgique.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Israël', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Israël'), 'website' => 'www.ambacita.org'],

            // Représentations en Amérique
            ['name' => 'Ambassade de Côte d\'Ivoire aux États-Unis', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire aux États-Unis'), 'website' => 'http://www.ambaciusa.org/Site/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Canada', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Canada'), 'website' => 'http://www.canada.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Brésil', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Brésil'), 'website' => 'http://www.bresil.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Mexique', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Mexique'), 'website' => 'http://www.mexique.diplomatie.gouv.ci/'],

            // Représentations en Afrique
            ['name' => 'Ambassade de Côte d\'Ivoire au Sénégal', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Sénégal'), 'website' => null],
            ['name' => 'Ambassade de Côte d\'Ivoire au Ghana', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Ghana'), 'website' => 'http://www.ghana.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Nigeria', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Nigeria'), 'website' => 'http://www.nigeria.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Maroc', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Maroc'), 'website' => 'http://www.maroc.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Algérie', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Algérie'), 'website' => null],
            ['name' => 'Ambassade de Côte d\'Ivoire en Tunisie', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Tunisie'), 'website' => 'http://www.tunisie.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Égypte', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Égypte'), 'website' => 'http://www.egypte.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Mali', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Mali'), 'website' => 'http://www.mali.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Burkina Faso', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Burkina Faso'), 'website' => null],
            ['name' => 'Ambassade de Côte d\'Ivoire au Togo', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Togo'), 'website' => 'http://www.ghana.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Bénin', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Bénin'), 'website' => 'http://www.nigeria.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Cameroun', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Cameroun'), 'website' => 'http://www.cameroun.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Liberia', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Liberia'), 'website' => 'http://www.liberia.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Guinée', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Guinée'), 'website' => 'http://www.guinee.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Gabon', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Gabon'), 'website' => 'http://www.gabon.diplomatie.gouv.ci/'],

            // Représentations en Asie
            ['name' => 'Ambassade de Côte d\'Ivoire en Chine', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Chine'), 'website' => 'http://www.chine.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire au Japon', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire au Japon'), 'website' => 'http://www.japon.diplomatie.gouv.ci/'],
            ['name' => 'Ambassade de Côte d\'Ivoire en Inde', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Inde'), 'website' => 'http://www.amb2ci-inde.org/'],
            ['name' => 'Ambassade de Côte d\'Ivoire aux Émirats Arabes Unis', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire aux Émirats Arabes Unis'), 'website' => null],
            ['name' => 'Ambassade de Côte d\'Ivoire en Arabie Saoudite', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Arabie Saoudite'), 'website' => 'www.arabiesaoudite.diplomatie.gouv.ci/'],

            // Représentations en Océanie
            ['name' => 'Ambassade de Côte d\'Ivoire en Australie', 'slug' => Str::slug('Ambassade de Côte d\'Ivoire en Australie'), 'website' => 'http://www.japon.diplomatie.gouv.ci/'],
        ];

        foreach ($ambassades as $ambassade) {
            DB::table('ambassades')->insert($ambassade);
        }
    }
}
