<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class GroupementProfessionnelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $groups = [
            ['name' => 'APBEF-CI', 'slug' => Str::slug('APBEF-CI'), 'website' => 'apbef-ci.net/'],
            ['name' => 'ASACI', 'slug' => Str::slug('ASACI'), 'website' => 'www.asaci.net'],
            ['name' => 'CCILCI', 'slug' => Str::slug('CCILCI'), 'website' => 'www.ccilci.org'],
            ['name' => 'FEDERMAR', 'slug' => Str::slug('FEDERMAR'), 'website' => null],
            ['name' => 'FNISCI', 'slug' => Str::slug('FNISCI'), 'website' => 'www.fnisci.net'],
            ['name' => 'GIBTP', 'slug' => Str::slug('GIBTP'), 'website' => 'gibtp.ci'],
            ['name' => 'GIPAME', 'slug' => Str::slug('GIPAME'), 'website' => null],
            ['name' => 'GPMCI', 'slug' => Str::slug('GPMCI'), 'website' => 'www.chambredesmines.org'],
            ['name' => 'GPP', 'slug' => Str::slug('GPP'), 'website' => null],
            ['name' => 'UGECI', 'slug' => Str::slug('UGECI'), 'website' => null],
            ['name' => 'UNETEL', 'slug' => Str::slug('UNETEL'), 'website' => 'www.unetelci.org'],
        ];

        foreach ($groups as $group) {
            DB::table('groupement_professionnels')->insert($group);
        }
    }
}
