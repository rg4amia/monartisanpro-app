<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class GrandEntrepriseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $companies = [
            ['name' => 'AW2A', 'slug' => Str::slug('AW2A'), 'website' => null],
            ['name' => 'BAYER WCA', 'slug' => Str::slug('BAYER WCA'), 'website' => 'www.bayer.com'],
            ['name' => 'COLAS', 'slug' => Str::slug('COLAS'), 'website' => 'www.colas.com'],
            ['name' => 'DANONE NUTRICA', 'slug' => Str::slug('DANONE NUTRICA'), 'website' => 'www.danone.com'],
            ['name' => 'EOLIS SA', 'slug' => Str::slug('EOLIS SA'), 'website' => 'www.eolislogistque.com'],
            ['name' => 'G4S SECURE SOLUTIONS (CI)', 'slug' => Str::slug('G4S SECURE SOLUTIONS CI'), 'website' => 'www.g4s.ci'],
            ['name' => 'LTF', 'slug' => Str::slug('LTF'), 'website' => 'www.latulipefood.com'],
            ['name' => 'LCR', 'slug' => Str::slug('LCR'), 'website' => 'www.groupecentaures.com'],
            ['name' => 'LDFG', 'slug' => Str::slug('LDFG'), 'website' => 'www.logis-ci.com'],
            ['name' => 'MIB', 'slug' => Str::slug('MIB'), 'website' => 'www.mib.ci'],
            ['name' => 'MIBEM', 'slug' => Str::slug('MIBEM'), 'website' => 'www.mib.ci'],
            ['name' => 'NKC', 'slug' => Str::slug('NKC'), 'website' => 'www.kaeracosmetic.com'],
            ['name' => 'SAE', 'slug' => Str::slug('SAE'), 'website' => null],
            ['name' => 'PRESTIMEX CI', 'slug' => Str::slug('PRESTIMEX CI'), 'website' => 'www.prestimex.com'],
            ['name' => 'SERVAIR', 'slug' => Str::slug('SERVAIR'), 'website' => 'www.servairabidjan.ci'],
            ['name' => 'SHM', 'slug' => Str::slug('SHM'), 'website' => null],
            ['name' => 'SICTA', 'slug' => Str::slug('SICTA'), 'website' => 'www.sicta.sgs.com'],
            ['name' => 'IVOSEP', 'slug' => Str::slug('IVOSEP'), 'website' => 'www.ivosep.ci'],
            ['name' => 'SISAG', 'slug' => Str::slug('SISAG'), 'website' => 'www.sisagci.com'],
            ['name' => 'TSP', 'slug' => Str::slug('TSP'), 'website' => 'www.tsp-ci.com'],
            ['name' => 'WAVE', 'slug' => Str::slug('WAVE'), 'website' => 'www.wave.com'],
        ];

        foreach ($companies as $company) {
            DB::table('grand_entreprises')->insert($company);
        }
    }
}
