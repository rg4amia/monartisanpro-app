<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class InstitutionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('institutions')->insert([
            [
                'name' => 'Sénat de Côte d\'Ivoire',
                'slug' => 'senat-cote-d-ivoire',
                'description' => 'Sénat de Côte d\'Ivoire',
                'logo' => 'parlement_logo.png',
                'website' => 'www.parlement.ci',
                'email' => 'info@parlement.ci',
                'phone' => '+225 20 22 00 00',
                'address' => 'Plateau, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'Le Parlement (composé de l’Assemblée Nationale et du Sénat)',
                'slug' => 'le-parlement-composé-de-l-assemblée-nationale-et-du-sénat',
                'description' => 'Institution législative composée de l\'Assemblée Nationale et du Sénat.',
                'logo' => 'parlement_logo.png',
                'website' => 'www.parlement.ci',
                'email' => 'info@parlement.ci',
                'phone' => '+225 20 22 00 00',
                'address' => 'Plateau, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'Le Conseil Constitutionnel',
                'slug' => 'le-conseil-constitutionnel',
                'description' => 'Institution chargée de veiller à la constitutionnalité des lois et règlements.',
                'logo' => 'conseil_constitutionnel_logo.png',
                'website' => 'www.conseil-constitutionnel.ci',
                'email' => 'contact@conseil-constitutionnel.ci',
                'phone' => '+225 20 22 22 22',
                'address' => 'Cocody, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'La Cour de Cassation',
                'slug' => 'la-cour-de-cassation',
                'description' => 'La plus haute juridiction de l\'ordre judiciaire.',
                'logo' => 'cour_cassation_logo.png',
                'website' => 'www.courdecassation.ci',
                'email' => 'contact@courdecassation.ci',
                'phone' => '+225 20 21 00 00',
                'address' => 'Plateau, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'Conseil d\'Etat',
                'slug' => 'conseil-d-etat',
                'description' => 'Institution suprême de l\'ordre administratif.',
                'logo' => 'conseil_etat_logo.png',
                'website' => 'www.conseildetat.ci',
                'email' => 'contact@conseildetat.ci',
                'phone' => '+225 20 23 00 00',
                'address' => 'Cocody, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'La Cour des Comptes',
                'slug' => 'la-cour-des-comptes',
                'description' => 'Institution chargée du contrôle des finances publiques.',
                'logo' => 'cour_comptes_logo.png',
                'website' => 'www.courdescomptes.ci',
                'email' => 'info@courdescomptes.ci',
                'phone' => '+225 20 24 00 00',
                'address' => 'Plateau, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'Haute Cour de Justice',
                'slug' => 'haute-cour-de-justice',
                'description' => 'Juridiction compétente pour juger les hauts responsables de l\'État.',
                'logo' => 'haute_cour_justice_logo.png',
                'website' => 'www.hautecourjustice.ci',
                'email' => 'contact@hautecourjustice.ci',
                'phone' => '+225 20 25 00 00',
                'address' => 'Cocody, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'Le Conseil Economique, Social, Environnemental et Culturel',
                'slug' => 'le-conseil-économique-social-environnemental-et-culturel',
                'description' => 'Instance consultative sur les questions économiques, sociales, environnementales et culturelles.',
                'logo' => 'cesec_logo.png',
                'website' => 'www.cesec.ci',
                'email' => 'info@cesec.ci',
                'phone' => '+225 20 26 00 00',
                'address' => 'Plateau, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'Le Médiateur de la République',
                'slug' => 'le-médiateur-de-la-république',
                'description' => 'Institution de médiation entre les citoyens et l\'administration.',
                'logo' => 'mediateur_republique_logo.png',
                'website' => 'www.mediateur.ci',
                'email' => 'contact@mediateur.ci',
                'phone' => '+225 20 27 00 00',
                'address' => 'Cocody, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
            [
                'name' => 'La Chambre Nationale des Rois et Chefs Traditionnels',
                'slug' => 'la-chambre-nationale-des-rois-et-chefs-traditionnels',
                'description' => 'Instance regroupant les chefs traditionnels de Côte d\'Ivoire.',
                'logo' => 'chambre_rois_chefs_logo.png',
                'website' => 'www.roisetchefs.ci',
                'email' => 'info@roisetchefs.ci',
                'phone' => '+225 20 28 00 00',
                'address' => 'Plateau, Abidjan, Côte d\'Ivoire',
                'status' => 'active',
            ],
        ]);
    }
}
