<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class RegionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Les régions
        $regions = [
            ['name' => 'Abidjan', 'slug' => Str::slug('Abidjan')],
            ['name' => 'Agnéby-Tiassa', 'slug' => Str::slug('Agnéby-Tiassa')],
            ['name' => 'Bafing', 'slug' => Str::slug('Bafing')],
            ['name' => 'Bagoué', 'slug' => Str::slug('Bagoué')],
            ['name' => 'Bounkani', 'slug' => Str::slug('Bounkani')],
            ['name' => 'Bélier', 'slug' => Str::slug('Bélier')],
            ['name' => 'Béré', 'slug' => Str::slug('Béré')],
            ['name' => 'Cavally', 'slug' => Str::slug('Cavally')],
            ['name' => 'Folon', 'slug' => Str::slug('Folon')],
            ['name' => 'Gbèkè', 'slug' => Str::slug('Gbèkè')],
            ['name' => 'Gbôklè', 'slug' => Str::slug('Gbôklè')],
            ['name' => 'Gontougo', 'slug' => Str::slug('Gontougo')],
            ['name' => 'Grands-Ponts', 'slug' => Str::slug('Grands-Ponts')],
            ['name' => 'Guémon', 'slug' => Str::slug('Guémon')],
            ['name' => 'Gôh', 'slug' => Str::slug('Gôh')],
            ['name' => 'Hambol', 'slug' => Str::slug('Hambol')],
            ['name' => 'Haut-Sassandra', 'slug' => Str::slug('Haut-Sassandra')],
            ['name' => 'Iffou', 'slug' => Str::slug('Iffou')],
            ['name' => 'Indiéné-Djuablin', 'slug' => Str::slug('Indiéné-Djuablin')],
            ['name' => 'Kabadougou', 'slug' => Str::slug('Kabadougou')],
            ['name' => 'La Mé', 'slug' => Str::slug('La Mé')],
            ['name' => 'Loh-Djiboua', 'slug' => Str::slug('Loh-Djiboua')],
            ['name' => 'Marahoué', 'slug' => Str::slug('Marahoué')],
            ['name' => 'Moronou', 'slug' => Str::slug('Moronou')],
            ['name' => 'N\'Zi', 'slug' => Str::slug('N\'Zi')],
            ['name' => 'Nawa', 'slug' => Str::slug('Nawa')],
            ['name' => 'Poro', 'slug' => Str::slug('Poro')],
            ['name' => 'San-Pédro', 'slug' => Str::slug('San-Pédro')],
            ['name' => 'Sud-Comoé', 'slug' => Str::slug('Sud-Comoé')],
            ['name' => 'Tchologo', 'slug' => Str::slug('Tchologo')],
            ['name' => 'Tonkpi', 'slug' => Str::slug('Tonkpi')],
            ['name' => 'Worodougou', 'slug' => Str::slug('Worodougou')],
            ['name' => 'Yamoussoukro', 'slug' => Str::slug('Yamoussoukro')],
        ];
        DB::table('régions')->insert($regions);
    }
}
