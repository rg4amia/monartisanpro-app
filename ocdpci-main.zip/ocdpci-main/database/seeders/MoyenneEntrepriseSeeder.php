<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class MoyenneEntrepriseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $companies = [
            ['name' => 'FIRST BANK CI', 'slug' => Str::slug('FIRST BANK CI'), 'website' => 'www.afrilandfirstbankci.com'],
            ['name' => 'ALCI', 'slug' => Str::slug('ALCI'), 'website' => 'www.ci.airliquide.com'],
            ['name' => 'ASCOMA COTE D\'IVOIRE', 'slug' => Str::slug('ASCOMA COTE D\'IVOIRE'), 'website' => 'www.ascomaassurancestore.com'],
            ['name' => 'ATLANTIQUE FINANCE', 'slug' => Str::slug('ATLANTIQUE FINANCE'), 'website' => 'www.atlantiquefinance.net'],
            ['name' => 'BAT CI', 'slug' => Str::slug('BAT CI'), 'website' => 'www.bat.com'],
            ['name' => 'CIPHARM', 'slug' => Str::slug('CIPHARM'), 'website' => 'www.cipharm.ci'],
            ['name' => 'CIAT', 'slug' => Str::slug('CIAT'), 'website' => 'www.ciat.ci'],
            ['name' => 'CBC', 'slug' => Str::slug('CBC'), 'website' => 'www.cbc-ci.com'],
            ['name' => 'CREDIT ACCESS S.A', 'slug' => Str::slug('CREDIT ACCESS S.A'), 'website' => 'www.creditaccess.ci'],
            ['name' => 'DELOITTE CI', 'slug' => Str::slug('DELOITTE CI'), 'website' => 'www.deloitte.com'],
            ['name' => 'DHL - CI', 'slug' => Str::slug('DHL - CI'), 'website' => 'www.dhl.ci'],
            ['name' => 'DMEIB', 'slug' => Str::slug('DMEIB'), 'website' => 'www.dmeib-electric.com'],
            ['name' => 'E Y', 'slug' => Str::slug('E Y'), 'website' => 'www.ey.com/afrique_francophone'],
            ['name' => 'IUA', 'slug' => Str::slug('IUA'), 'website' => 'www.iua-ci.org'],
            ['name' => 'KOIRA HOTEL INVESTMENT SA', 'slug' => Str::slug('KOIRA HOTEL INVESTMENT SA'), 'website' => null],
            ['name' => 'KPMG CI', 'slug' => Str::slug('KPMG CI'), 'website' => 'www.kpmg.ci'],
            ['name' => 'LOGIS CI', 'slug' => Str::slug('LOGIS CI'), 'website' => 'www.logis-ci.com'],
            ['name' => 'LYDIA LUDIC CI', 'slug' => Str::slug('LYDIA LUDIC CI'), 'website' => 'www.lydialudic.com'],
            ['name' => 'N-SOCITECH', 'slug' => Str::slug('N-SOCITECH'), 'website' => 'www.socitech.com'],
            ['name' => 'MCG', 'slug' => Str::slug('MCG'), 'website' => 'www.mk-conseil.net'],
            ['name' => 'OIC', 'slug' => Str::slug('OIC'), 'website' => 'www.oic.ci'],
            ['name' => 'OUTRE HAIR', 'slug' => Str::slug('OUTRE HAIR'), 'website' => 'www.outre.com'],
            ['name' => 'PWC', 'slug' => Str::slug('PWC'), 'website' => 'www.pwc.com'],
            ['name' => 'SAHER', 'slug' => Str::slug('SAHER'), 'website' => null],
            ['name' => 'SCORE', 'slug' => Str::slug('SCORE'), 'website' => 'www.scoregroupe.ci'],
            ['name' => 'SIFCA SA', 'slug' => Str::slug('SIFCA SA'), 'website' => 'www.groupesifca.com'],
            ['name' => 'SMA BTA', 'slug' => Str::slug('SMA BTA'), 'website' => 'www.smabtp.ci'],
            ['name' => 'SOGEMED PISAM', 'slug' => Str::slug('SOGEMED PISAM'), 'website' => 'www.pisam.ci'],
            ['name' => 'SACRI', 'slug' => Str::slug('SACRI'), 'website' => 'www.sacri-ci.com'],
            ['name' => 'SNS', 'slug' => Str::slug('SNS'), 'website' => 'www.sns.ci'],
            ['name' => 'SEK', 'slug' => Str::slug('SEK'), 'website' => 'www.sek-ci.com'],
            ['name' => 'SITA', 'slug' => Str::slug('SITA'), 'website' => 'www.sita-sa.com'],
            ['name' => 'SNPECI', 'slug' => Str::slug('SNPECI'), 'website' => 'www.fratmat.info'],
            ['name' => 'TTS', 'slug' => Str::slug('TTS'), 'website' => 'www.tts-ci.com'],
        ];

        foreach ($companies as $company) {
            DB::table('moyenne_entreprises')->insert($company);
        }
    }
}
