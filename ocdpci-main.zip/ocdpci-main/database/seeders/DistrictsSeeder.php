<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class DistrictsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Districts autonomes
        $districts = [
            [
                'name' => 'Abidjan',
                'slug' => 'abidjan',
                'description' => 'District centre de la Côte d\'Ivoire, avec la capitale à Abidjan.',
                'logo' => null, // Ajoutez ici le chemin du logo si disponible
                'website' => 'abidjan.district.ci/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter', // Ajoutez le nom actuel du gouverneur
                'status' => 'active',
            ],
            [
                'name' => 'Bas-Sassandra',
                'slug' => 'bas-sassandra',
                'description' => 'District situé dans l\'ouest de la Côte d\'Ivoire, centré autour de San-Pédro.',
                'logo' => null, // Ajoutez ici le chemin du logo si disponible
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter', // Ajoutez le nom actuel du gouverneur
                'status' => 'active',
            ],
            [
                'name' => 'Comoé',
                'slug' => 'comoe',
                'description' => 'District situé dans l\'est de la Côte d\'Ivoire, avec la capitale à Abengourou.',
                'logo' => null,
                'website' => 'www.districtdelacomoe.ci/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Denguélé',
                'slug' => 'denguele',
                'description' => 'District dans le nord-ouest de la Côte d\'Ivoire, avec Odienné comme capitale.',
                'logo' => null,
                'website' => 'districtdudenguele.ci/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Gôh-Djiboua',
                'slug' => 'goh-djiboua',
                'description' => 'District situé dans le centre-ouest de la Côte d\'Ivoire, avec Gagnoa comme capitale.',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Lacs',
                'slug' => 'lacs',
                'description' => 'District autour de Yamoussoukro, la capitale politique et administrative.',
                'logo' => null,
                'website' => 'www.districtautonomedeslacs.ci/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Lagunes',
                'slug' => 'lagunes',
                'description' => 'District autour d\'Abidjan, la plus grande ville de la Côte d\'Ivoire.',
                'logo' => null,
                'website' => 'districtautonomedeslagunes.ci',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Montagnes',
                'slug' => 'montagnes',
                'description' => 'District situé dans l\'ouest de la Côte d\'Ivoire, avec Man comme capitale.',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Sassandra-Marahoué',
                'slug' => 'sassandra-marahoue',
                'description' => 'District dans le centre-ouest de la Côte d\'Ivoire, avec Daloa comme capitale.',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Savanes',
                'slug' => 'savanes',
                'description' => 'District dans le nord de la Côte d\'Ivoire, avec Korhogo comme capitale.',
                'logo' => null,
                'website' => 'savane.ci/tag/district-des-savanes/',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Vallée du Bandama',
                'slug' => 'vallee-du-bandama',
                'description' => 'District situé dans le centre de la Côte d\'Ivoire, avec Bouaké comme capitale.',
                'logo' => null,
                'website' => 'davb.ci/accueil',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Woroba',
                'slug' => 'woroba',
                'description' => 'District dans le nord-ouest de la Côte d\'Ivoire, avec Séguéla comme capitale.',
                'logo' => null,
                'website' => null,
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ],
            [
                'name' => 'Zanzan',
                'slug' => 'zanzan',
                'description' => 'District dans l\'est de la Côte d\'Ivoire, avec Bondoukou comme capitale.',
                'logo' => null,
                'website' => 'www.zanzan.ci',
                'email' => null,
                'phone' => null,
                'address' => null,
                'responsable' => 'Nom à compléter',
                'status' => 'active',
            ]
        ];

        DB::table('districts')->insert($districts);
    }
}
