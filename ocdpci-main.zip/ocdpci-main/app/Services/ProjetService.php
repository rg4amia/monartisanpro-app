<?php

namespace App\Services;

use App\Models\Ambassade;
use App\Models\Commune;
use App\Models\Gouvernement;
use App\Models\Institution;
use App\Models\Ministere;
use App\Models\District;
use App\Models\Syndicats;
use App\Models\Région;
use App\Models\AssociationProfessionnelle;
use App\Models\TresGrandEntreprise;
use App\Models\GrandEntreprise;
use App\Models\MoyenneEntreprise;
use App\Models\PetitEntreprise;
use App\Models\GroupementProfessionnel;

class ProjetService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function institutions()
    {
        return Institution::all();
    }

    public function gouvernements()
    {
        return Gouvernement::all();
    }

    public function districts()
    {
        return District::all();
    }

    public function regions()
    {
        return Région::all();
    }

    public function syndicats()
    {
        return Syndicats::all();
    }

    public function communes()
    {
        return Commune::all();
    }

    public static function tresgrdEntreprises()
    {
        return TresGrandEntreprise::orderBy('id', 'desc')->get();
    }

    public static function grdEntreprise()
    {
        return GrandEntreprise::orderBy('id', 'desc')->get();
    }

    public static function mynneEntreprise()
    {
        return MoyenneEntreprise::orderBy('id', 'desc')->get();
    }

    public static function ptEntreprise()
    {
        return PetitEntreprise::orderBy('id', 'desc')->get();
    }

    public static function grpementProfessionnel()
    {
        return GroupementProfessionnel::orderBy('id', 'desc')->get();
    }

    public static function associations()
    {
        return AssociationProfessionnelle::orderBy('id', 'desc')->get();
    }

    public function ambassade()
    {
        return Ambassade::all();
    }
}
