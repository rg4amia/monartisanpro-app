<?php

namespace App\Services;

use App\Models\News;

class NewsService
{
    /**
     * Create a new class instance.
     */
    public function __construct()
    {
        //
    }

    public function news()
    {
        return News::limit(value: 3)->get();
    }
}
