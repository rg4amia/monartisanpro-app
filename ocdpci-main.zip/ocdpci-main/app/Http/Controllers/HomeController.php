<?php

namespace App\Http\Controllers;

use Illuminate\View\View;
use App\Services\NewsService;
use App\Services\ProjetService;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public $projetService;
    public $newsService;
    private $usedRankings = [];

    public function __construct(ProjetService $projetService, NewsService $newsService)
    {
        $this->projetService = $projetService;
        $this->newsService = $newsService;
    }

    public function index(): View
    {
        $institutions = $this->projetService->institutions();
        $gouvernements = $this->projetService->gouvernements();
        $districts = $this->projetService->districts();
        $regions = $this->projetService->regions();
        $syndicats = $this->projetService->syndicats();
        $news = $this->newsService->news();
        $communes = $this->projetService->communes();
        $ambassades = $this->projetService->ambassade();

        $all_sites = [
            'institutions' => $institutions,
            'gouvernements' => $gouvernements,
            'districts' => $districts,
            'regions' => $regions,
            'syndicats' => $syndicats,
            'communes' => $communes,
            'ambassades' => $ambassades,
            'associations' => $this->projetService->associations(),
            'tresgrdEntreprises' => $this->projetService->tresgrdEntreprises(),
            'grdEntreprise' => $this->projetService->grdEntreprise(),
            'mynneEntreprise' => $this->projetService->mynneEntreprise(),
            'ptEntreprise' => $this->projetService->ptEntreprise(),
            'grpementProfessionnel' => $this->projetService->grpementProfessionnel(),
        ];

        $data_site_all = [];

        // Afficher tous les sites avec toutes leurs colonnes
        foreach ($all_sites as $type => $sites) {
            foreach ($sites as $site) {
                $data_site_all[] = [
                    'type' => $type,
                    'id' => $site->id,
                    'name' => $site->name,
                    'slug' => $site->slug,
                    'description' => $site->description ?? null,
                    'logo' => $site->logo ?? null,
                    'website' => $site->website ?? null,
                    'contact' => $site->contact ?? null,
                    'classement' => "#" . $this->generateUniqueRanking($site->id), // Unique French-style ranking
                ];
            }
        }

        // Trier les sites par classement
        usort($data_site_all, function ($a, $b) {
            // Extraire le numéro de classement et le convertir en entier
            $rankA = intval(str_replace('#', '', $a['classement']));
            $rankB = intval(str_replace('#', '', $b['classement']));

            return $rankA - $rankB;
        });

        $projet = $this->projetService;

        // Vous pouvez passer des données dynamiques si nécessaire
        $data = [
            'heroSliderContent' => view('partials.hero-slider')->render(),
            'categoriesContent' => view('partials.categories')->render(),
            'aboutContent' => view('partials.about')->render(),
            'campaignContent' => view('partials.campaign', compact(
                'institutions',
                'gouvernements',
                'districts',
                'regions',
                'syndicats',
                'communes',
                'data_site_all',
                'projet',
                'ambassades'
            ))->render(),
            'campaignTwoContent' => view('partials.campaign-two')->render(),
            'contentOne' => view('partials.content-one')->render(),
            'brandOne' => view('partials.brand-one')->render(),
            'mainCtaOne' => view('partials.main-cta-one')->render(),
            'mainGallery' => view('partials.main-gallery')->render(),
            'videoOne' => view('partials.video-one')->render(),
            'mainTestimonialContent' => view('partials.main-testimonial')->render(),
            'ourBeenfitContent' => view('partials.our-beenfit')->render(),
            'subscribeContent' => view('partials.subscribe')->render(),
            'newsContent' => view('partials.news', compact('news'))->render(),
            'data_site_all' => $data_site_all,
        ];

        return view('home', $data);
    }

    /**
     * Generate a unique ranking for a site based on its ID
     *
     * @param int $siteId
     * @return int
     */
    public function generateUniqueRanking($id)
    {
        // Générer un classement séquentiel simple
        static $currentRanking = 1;

        // Mémoriser le classement utilisé
        $this->usedRankings[] = $currentRanking;

        // Format français avec leading zeros (ex: 01, 02, 03, etc.)
        $formattedRanking = sprintf("%02d", $currentRanking);

        // Incrémenter pour le prochain appel
        $currentRanking++;

        return $formattedRanking;
    }
}
