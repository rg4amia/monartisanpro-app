<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class UserManagementController extends Controller
{
 public function index()
 {
  $users = User::paginate(10);
  return view('users.index', compact('users'));
 }

 public function create()
 {
  return view('users.create');
 }

 public function store(Request $request)
 {
  $validated = $request->validate([
   'name' => 'required|string|max:255',
   'email' => 'required|string|email|max:255|unique:users',
   'password' => 'required|string|min:8|confirmed',
   'role' => 'nullable|in:admin,editor,viewer',
  ]);

  $user = User::create([
   'name' => $validated['name'],
   'email' => $validated['email'],
   'password' => bcrypt($validated['password']),
   'role' => $validated['role'] ?? 'viewer',
  ]);

  return redirect()->route('users.index')->with('success', 'Utilisateur créé avec succès');
 }

 // Autres méthodes CRUD
}
