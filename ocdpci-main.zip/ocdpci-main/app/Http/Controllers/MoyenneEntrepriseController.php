<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\MoyenneEntreprise;

class MoyenneEntrepriseController extends Controller
{

    public function index() {
        $entreprises = MoyenneEntreprise::all();
        $title = 'Moyenne Entreprise';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.moyenne-entreprise', compact('entreprises', 'title', 'description'));
    }
}
