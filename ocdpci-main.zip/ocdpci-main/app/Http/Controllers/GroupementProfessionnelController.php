<?php

namespace App\Http\Controllers;

use App\Models\GroupementProfessionnel;
use Illuminate\Http\Request;

class GroupementProfessionnelController extends Controller
{
    public function index()
    {
        $groupements = GroupementProfessionnel::all();
        $title = 'Groupements Professionnels';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.groupements-professionnels', compact('groupements', 'title', 'description'));
    }
}
