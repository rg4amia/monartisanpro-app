<?php

namespace App\Http\Controllers;

use App\Models\TresGrandEntreprise;
use Illuminate\Http\Request;

class TresGrandeEntrepriseController extends Controller
{
    public function index()
    {
        $entreprises = TresGrandEntreprise::all();
        $title = 'Trés Grande Entreprise';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.tres-grande-entreprise', compact('entreprises', 'title', 'description'));
    }
}
