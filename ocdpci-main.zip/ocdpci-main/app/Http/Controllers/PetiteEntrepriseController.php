<?php

namespace App\Http\Controllers;

use App\Models\PetitEntreprise;
use Illuminate\Http\Request;

class PetiteEntrepriseController extends Controller
{
    public function index()
    {
        $entreprises = PetitEntreprise::all();
        $title = 'Petite Entreprise';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.petite-entreprise', compact('entreprises', 'title', 'description'));
    }
}
