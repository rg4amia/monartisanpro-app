<?php

namespace App\Http\Controllers;

use App\Models\District;
use App\Models\Institution;

class ReportController extends Controller
{
 public function index()
 {
  return view('reports.index');
 }

 public function districts()
 {
  $districts = District::all();
  return view('reports.districts', compact('districts'));
 }

 public function institutions()
 {
  $institutions = Institution::all();
  return view('reports.institutions', compact('institutions'));
 }
}
