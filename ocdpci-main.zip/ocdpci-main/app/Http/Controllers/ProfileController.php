<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
 public function edit()
 {
  return view('profile.edit', [
   'user' => Auth::user(),
  ]);
 }

 public function update(Request $request)
 {
  $user = Auth::user();

  $validated = $request->validate([
   'name' => ['string', 'max:255'],
   'email' => ['email', 'max:255', Rule::unique('users')->ignore($user->id)],
  ]);

  $user->update([
   'name' => $validated['name'],
   'email' => $validated['email'],
  ]);

  if ($user->wasChanged('email')) {
   $user->email_verified_at = null;
   $user->save();
  }

  return Redirect::route('profile.edit')->with('status', 'profile-updated');
 }

 public function destroy(Request $request)
 {
  $request->validateWithBag('userDeletion', [
   'password' => ['required', 'current_password'],
  ]);

  $user = $request->user();

  Auth::logout();

  $user->delete();

  $request->session()->invalidate();
  $request->session()->regenerateToken();

  return Redirect::to('/');
 }
}
