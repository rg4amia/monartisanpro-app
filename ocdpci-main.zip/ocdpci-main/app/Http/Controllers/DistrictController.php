<?php

namespace App\Http\Controllers;

use App\Models\District;
use Illuminate\Http\Request;

class DistrictController extends Controller
{
 public function index()
 {
  $districts = District::paginate(10);
  return view('districts.index', compact('districts'));
 }

 public function create()
 {
  return view('districts.create');
 }

 public function store(Request $request)
 {
  $validatedData = $request->validate([
   'name' => 'required|max:255',
   'slug' => 'required|unique:districts',
   'description' => 'nullable',
   'logo' => 'nullable|image',
   'website' => 'nullable|url',
   'email' => 'nullable|email',
   'phone' => 'nullable|string',
   'address' => 'nullable|string',
   'responsable' => 'nullable|string',
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('districts', 'public');
   $validatedData['logo'] = $logoPath;
  }

  District::create($validatedData);

  return redirect()->route('districts.index')
   ->with('success', 'District créé avec succès.');
 }

 public function edit(District $district)
 {
  return view('districts.edit', compact('district'));
 }

 public function update(Request $request, District $district)
 {
  $validatedData = $request->validate([
   // Mêmes règles que store()
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('districts', 'public');
   $validatedData['logo'] = $logoPath;
  }

  $district->update($validatedData);

  return redirect()->route('districts.index')
   ->with('success', 'District mis à jour avec succès.');
 }

 public function destroy(District $district)
 {
  $district->delete();

  return redirect()->route('districts.index')
   ->with('success', 'District supprimé avec succès.');
 }
}
