<?php

namespace App\Http\Controllers;

use App\Models\AssociationProfessionnelle;
use Illuminate\Http\Request;

class AssociationProfessionnelController extends Controller
{
    public function index()
    {
        $associations = AssociationProfessionnelle::all();
        $title = 'Associations Professionnelles';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.associations-professionnels', compact('associations', 'title', 'description'));
    }

}
