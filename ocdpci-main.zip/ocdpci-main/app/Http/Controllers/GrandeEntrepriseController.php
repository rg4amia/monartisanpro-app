<?php

namespace App\Http\Controllers;

use App\Models\GrandeEntreprise;
use Illuminate\Http\Request;

class GrandeEntrepriseController extends Controller
{
    public function index()
    {
        $entreprises = GrandeEntreprise::all();
        $title = 'Grande Entreprise';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.grande-entreprise', compact('entreprises', 'title', 'description'));
    }
}
