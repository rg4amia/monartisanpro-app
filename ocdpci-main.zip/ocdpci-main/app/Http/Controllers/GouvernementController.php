<?php

namespace App\Http\Controllers;

use App\Models\Gouvernement;
use Illuminate\Http\Request;

class GouvernementController extends Controller
{
 public function index()
 {
  $gouvernements = Gouvernement::paginate(10);
  return view('gouvernements.index', compact('gouvernements'));
 }

 public function create()
 {
  return view('gouvernements.create');
 }

 public function store(Request $request)
 {
  $validatedData = $request->validate([
   'name' => 'required|max:255',
   'slug' => 'required|unique:gouvernements',
   'description' => 'nullable',
   'logo' => 'nullable|image',
   'website' => 'nullable|url',
   'email' => 'nullable|email',
   'phone' => 'nullable|string',
   'address' => 'nullable|string',
   'responsable' => 'nullable|string',
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('gouvernements', 'public');
   $validatedData['logo'] = $logoPath;
  }

  Gouvernement::create($validatedData);

  return redirect()->route('gouvernements.index')
   ->with('success', 'Gouvernement créé avec succès.');
 }

 public function edit(Gouvernement $gouvernement)
 {
  return view('gouvernements.edit', compact('gouvernement'));
 }

 public function update(Request $request, Gouvernement $gouvernement)
 {
  $validatedData = $request->validate([
   // Mêmes règles que store()
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('gouvernements', 'public');
   $validatedData['logo'] = $logoPath;
  }

  $gouvernement->update($validatedData);

  return redirect()->route('gouvernements.index')
   ->with('success', 'Gouvernement mis à jour avec succès.');
 }

 public function destroy(Gouvernement $gouvernement)
 {
  $gouvernement->delete();

  return redirect()->route('gouvernements.index')
   ->with('success', 'Gouvernement supprimé avec succès.');
 }
}
