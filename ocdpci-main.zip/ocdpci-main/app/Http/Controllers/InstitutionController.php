<?php

namespace App\Http\Controllers;

use App\Models\Institution;
use Illuminate\Http\Request;

class InstitutionController extends Controller
{
 public function index()
 {
  $institutions = Institution::paginate(10);
  return view('institutions.index', compact('institutions'));
 }

 public function create()
 {
  return view('institutions.create');
 }

 public function store(Request $request)
 {
  $validatedData = $request->validate([
   'name' => 'required|max:255',
   'slug' => 'required|unique:institutions',
   'description' => 'nullable',
   'logo' => 'nullable|image',
   'website' => 'nullable|url',
   'email' => 'nullable|email',
   'phone' => 'nullable|string',
   'address' => 'nullable|string',
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('institutions', 'public');
   $validatedData['logo'] = $logoPath;
  }

  Institution::create($validatedData);

  return redirect()->route('institutions.index')
   ->with('success', 'Institution créée avec succès.');
 }

 public function edit(Institution $institution)
 {
  return view('institutions.edit', compact('institution'));
 }

 public function update(Request $request, Institution $institution)
 {
  $validatedData = $request->validate([
   // Mêmes règles que store()
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('institutions', 'public');
   $validatedData['logo'] = $logoPath;
  }

  $institution->update($validatedData);

  return redirect()->route('institutions.index')
   ->with('success', 'Institution mise à jour avec succès.');
 }

 public function destroy(Institution $institution)
 {
  $institution->delete();

  return redirect()->route('institutions.index')
   ->with('success', 'Institution supprimée avec succès.');
 }
}
