<?php

namespace App\Http\Controllers;

use App\Models\Région;
use Illuminate\Http\Request;

class RégionController extends Controller
{
 public function index()
 {
  $regions = Région::paginate(10);
  return view('regions.index', compact('regions'));
 }

 public function create()
 {
  return view('regions.create');
 }

 public function store(Request $request)
 {
  $validatedData = $request->validate([
   'name' => 'required|max:255',
   'slug' => 'required|unique:régions',
   'description' => 'nullable',
   'logo' => 'nullable|image',
   'website' => 'nullable|url',
   'email' => 'nullable|email',
   'phone' => 'nullable|string',
   'address' => 'nullable|string',
   'responsable' => 'nullable|string',
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('regions', 'public');
   $validatedData['logo'] = $logoPath;
  }

  Région::create($validatedData);

  return redirect()->route('regions.index')
   ->with('success', 'Région créée avec succès.');
 }

 public function edit(Région $region)
 {
  return view('regions.edit', compact('region'));
 }

 public function update(Request $request, Région $region)
 {
  $validatedData = $request->validate([
   // Mêmes règles que store()
  ]);

  if ($request->hasFile('logo')) {
   $logoPath = $request->file('logo')->store('regions', 'public');
   $validatedData['logo'] = $logoPath;
  }

  $region->update($validatedData);

  return redirect()->route('regions.index')
   ->with('success', 'Région mise à jour avec succès.');
 }

 public function destroy(Région $region)
 {
  $region->delete();

  return redirect()->route('regions.index')
   ->with('success', 'Région supprimée avec succès.');
 }
}
