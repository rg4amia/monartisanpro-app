<?php

namespace App\Http\Controllers;

use Illuminate\View\View;

class AboutController extends Controller
{
    public function index(): View
    {
        $aboutContent = view('partials.about')->render();
        return view('about', compact('aboutContent'));
    }
}
