<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Ambassade;

class AmbassadeController extends Controller
{
    public function index()
    {
        $ambassades = Ambassade::all();
        $title = 'Ambassade';
        $description = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.";
        return view('projects.ambassade', compact('ambassades', 'title', 'description'));
    }
}
