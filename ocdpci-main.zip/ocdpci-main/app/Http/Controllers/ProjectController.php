<?php

namespace App\Http\Controllers;

use App\Services\ProjetService;
use Illuminate\View\View;

class ProjectController extends Controller
{
    public $projetService;

    public function __construct(ProjetService $projetService)
    {
        $this->projetService = $projetService;
    }

    public function index(): View
    {
        return view('projects.index');
    }

    public function details(): View
    {
        return view('projects.details');
    }

    public function institutions(): View
    {
        $institutions = $this->projetService->institutions();
        return view('projects.institutions', [
            'institutions' => $institutions,
            'title' => 'Institutions',
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.',
        ]);
    }

    public function ministeres(): View
    {
        $gouvernements = $this->projetService->gouvernements();

        return view('projects.ministeres', [
            'gouvernements' => $gouvernements,
            'title' => 'Ministères',
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.',
        ]);
    }

    public function districts(): View
    {
        $districts = $this->projetService->districts();
        return view('projects.districts', [
            'districts' => $districts,
            'title' => 'Districts Autonomes',
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.',
        ]);
    }

    public function communes(): View
    {
        $communes = $this->projetService->communes();
        return view('projects.communes', [
            'communes' => $communes,
            'title' => 'Communes',
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.',
        ]);
    }

    public function conseilRegionale(): View
    {
        $regions = $this->projetService->regions();
        return view('projects.conseils-regionales', [
            'regions' => $regions,
            'title' => 'Conseils Régionaux',
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.',
        ]);
    }

    public function centraleSyndicales(): View
    {
        $syndicats = $this->projetService->syndicats();
        return view('projects.centrale-syndicales', [
            'syndicats' => $syndicats,
            'title' => 'Centrale Syndicales',
            'description' => 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quisquam, quos.',
        ]);
    }
}
