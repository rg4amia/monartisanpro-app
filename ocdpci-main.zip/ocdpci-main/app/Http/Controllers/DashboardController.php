<?php

namespace App\Http\Controllers;

use App\Models\District;
use App\Models\Institution;
use App\Models\Gouvernement;
use App\Models\Région;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
 public function index()
 {
  $stats = [
   'districts_count' => District::count(),
   'institutions_count' => Institution::count(),
   'gouvernements_count' => Gouvernement::count(),
   'regions_count' => Région::count(),
  ];

  return view('dashboard', compact('stats'));
 }
}
