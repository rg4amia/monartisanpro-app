<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GrandeEntreprise extends Model
{
    use HasFactory;

    protected $table = "grand_entreprises";

    protected $fillable = [
        'name',
        'description',
        'address',
        'contact',
        'website',
        'logo'
    ];
}
