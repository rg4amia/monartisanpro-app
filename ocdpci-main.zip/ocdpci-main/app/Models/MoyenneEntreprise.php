<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MoyenneEntreprise extends Model
{
    //
}
