<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class News extends Model
{
 use HasFactory;

 protected $fillable = [
  'title',
  'content',
  'image',
  'publication_date',
  'author_id',
  'comment_count'
 ];

 protected $dates = ['publication_date'];

 public function author()
 {
  return $this->belongsTo(User::class, 'author_id');
 }
}
