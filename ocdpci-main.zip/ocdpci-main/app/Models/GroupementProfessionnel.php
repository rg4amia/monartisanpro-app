<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GroupementProfessionnel extends Model
{
    //
}
