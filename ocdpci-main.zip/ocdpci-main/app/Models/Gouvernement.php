<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gouvernement extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'description',
        'logo',
        'website',
        'email',
        'phone',
        'address',
        'responsable',
        'status'
    ];
}
