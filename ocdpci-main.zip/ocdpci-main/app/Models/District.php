<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class District extends Model
{
    protected $fillable = [
        'name',
        'slug',
        'description',
        'logo',
        'website',
        'email',
        'phone',
        'address',
        'responsable',
        'status'
    ];

    public function getWebsiteAttribute($value)
    {
        return $value ?? '';
    }
}
