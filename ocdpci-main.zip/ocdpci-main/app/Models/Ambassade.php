<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Ambassade extends Model
{
    //
}
