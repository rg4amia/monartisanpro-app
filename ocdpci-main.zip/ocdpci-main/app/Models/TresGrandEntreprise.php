<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TresGrandEntreprise extends Model
{
    //
}
