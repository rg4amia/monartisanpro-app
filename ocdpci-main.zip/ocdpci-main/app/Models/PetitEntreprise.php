<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PetitEntreprise extends Model
{
    //
}
