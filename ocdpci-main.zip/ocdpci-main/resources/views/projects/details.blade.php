@extends('layouts.app')

@section('content')
    <h1>Project Details</h1>
@endsection
