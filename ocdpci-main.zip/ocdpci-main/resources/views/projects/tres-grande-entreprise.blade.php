@extends('layouts.app')

@section('content')
    <style>
        .campaign-one__single {
            border: 1px solid #bab9b9;
        }

        .nav-tabs-dark {
            background: #005826;
            border-radius: 100px;
            padding: 8px;
            gap: 8px;
            display: flex;
            justify-content: center;
            border: none;
            width: 100%;
        }

        .nav-tabs-dark .nav-item {
            margin: 0;
        }

        .nav-tabs-dark .nav-link {
            border-radius: 100px;
            padding: 12px 24px;
            color: white;
            border: none;
            transition: background-color 0.3s ease;
        }

        .nav-tabs-dark .nav-link:hover {
            background: #026c30;
            color: white;
        }

        .nav-tabs-dark .nav-link.active {
            background: #026c30;
            color: white;
            border: none;
        }
    </style>
    <section class="page-header">
        <div class="page-header__bg" style="background-image: url(assets/images/page-header/page-header.jpg);">

        </div>
        <!-- /.page-header__bg -->
        <div class="page-header__shape">
            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
        </div>

        <div class="container">
            <ul class="qizon-breadcrumb list-unstyled">
                <li><a href="{{ route('home') }}">Accueil</a></li>
                <span>/</span>
                <li><span>{{ $title }}</span></li>
            </ul><!-- /.thm-breadcrumb list-unstyled -->
            <h2 class="page-header__title">Projets</h2>
        </div><!-- /.container -->
    </section><!-- /.page-header -->
    <section class="campaign-one section-space-top">
        <div class="container">
            <div class="campaign-one__wrapper">
                <div class="sec-title">
                    <h6 class="text-center sec-title__tagline">Vos visites détermineront chaque positionnement</h6>
                    <h2 class="text-center sec-title__title">Explorer les très grandes entreprises</h2>
                </div>

                <div class="campaign-tabs">
                    <ul class="rounded nav nav-tabs nav-tabs-dark justify-content-center" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="rounded nav-link active" data-bs-toggle="tab" data-bs-target="#site-disponible"
                                type="button" role="tab">Site disponible</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#site-non-disponible"
                                type="button" role="tab">Site non disponible</button>
                        </li>
                    </ul>

                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="site-disponible" role="tabpanel">
                            <div class="row pt-30">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover" id="tresGrandesEntreprisesTable"
                                        style="border: 2px solid #026c30;">
                                        <thead style="background-color: #026c30; color: white;">
                                            <tr>
                                                <th>Classement</th>
                                                <th>Site Web</th>
                                                <th>Chgt de rang</th>
                                                <th>Durée moyenne de la visite</th>
                                                <th>Pages/visite</th>
                                                <th>Taux de rebond</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($entreprises as $entreprise)
                                             @if($entreprise->website != null)
                                                <tr style="transition: background-color 0.3s ease;">
                                                    <td style="color: #026c30; font-weight: bold;">-</td>
                                                    <td>
                                                        @if ($entreprise->slug)
                                                            <img src="{{ asset('assets/images/logo-structure/' . $entreprise->slug . '.png') }}"
                                                                alt=""
                                                                style="width: 50px; height: 35px; margin-right: 10px; vertical-align: middle;">
                                                        @endif
                                                        <a href="{{ $entreprise->website }}" target="_blank"
                                                            style="color: #ff6600; text-decoration: none;">{{ $entreprise->name }}</a>
                                                    </td>
                                                    <td style="color: #ff6600;">-</td>
                                                    <td style="color: #026c30;">-</td>
                                                    <td style="color: #ff6600;">-</td>
                                                    <td style="color: #026c30;">-</td>
                                                </tr>
                                                @endif
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="site-non-disponible" role="tabpanel">
                            <div class="row pt-30">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover"
                                        id="tresGrandesEntreprisesNonDisponiblesTable" style="border: 2px solid #026c30;">
                                        <thead style="background-color: #026c30; color: white;">
                                            <tr>
                                                <th>Classement</th>
                                                <th>Site Web</th>
                                                <th>Chgt de rang</th>
                                                <th>Durée moyenne de la visite</th>
                                                <th>Pages/visite</th>
                                                <th>Taux de rebond</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($entreprises as $entreprise)
                                             @if($entreprise->website == null)
                                                <tr style="transition: background-color 0.3s ease;">
                                                    <td style="color: #026c30; font-weight: bold;">-</td>
                                                    <td>
                                                        @if ($entreprise->slug)
                                                            <img src="{{ asset('assets/images/logo-structure/' . $entreprise->slug . '.png') }}"
                                                                alt=""
                                                                style="width: 50px; height: 35px; margin-right: 10px; vertical-align: middle;">
                                                        @endif
                                                        <a href="{{ $entreprise->website }}" target="_blank"
                                                            style="color: #ff6600; text-decoration: none;">{{ $entreprise->name }}</a>
                                                    </td>
                                                    <td style="color: #ff6600;">-</td>
                                                    <td style="color: #026c30;">-</td>
                                                    <td style="color: #ff6600;">-</td>
                                                    <td style="color: #026c30;">-</td>
                                                </tr>
                                                @endif
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.campaign-one__wrapper -->
        </div><!-- /.container-->
    </section><!-- /.campaign-one -->
@endsection
<script>
    document.addEventListener('DOMContentLoaded', function() {
        console.log(111);
        if (window.DataTable) {
            let tresGrandesEntreprisesTable = new DataTable('#tresGrandesEntreprisesTable');
            let tresGrandesEntreprisesNonDisponiblesTable = new DataTable(
                '#tresGrandesEntreprisesNonDisponiblesTable');
            console.log('DataTables initialized for tres grandes entreprises');
        } else {
            console.error('DataTables not loaded');
        }
    });
</script>

