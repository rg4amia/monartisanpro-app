@extends('layouts.app')

@section('content')
      <section class="page-header">
            <div class="page-header__bg" style="background-image: url(assets/images/page-header/page-header.jpg);">

            </div>
            <!-- /.page-header__bg -->
            <div class="page-header__shape">
                <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
            </div>

            <div class="container">
                <ul class="qizon-breadcrumb list-unstyled">
                    <li><a href="index.html">Accueil</a></li>
                    <span>/</span>
                    <li><span>Contact</span></li>
                </ul><!-- /.thm-breadcrumb list-unstyled -->
                <h2 class="page-header__title">Contact</h2>
            </div><!-- /.container -->
        </section><!-- /.page-header -->


        <section class="contact-page">
            <div class="container">
                <div class="contact-page__content">
                    <div class="sec-title">
                        <h6 class="text-center sec-title__tagline">Contactez-nous
                        </h6><!-- /.sec-title__tagline -->
                        <h2 class="text-center sec-title__title">
                            Écrivez un message</h2><!-- /.sec-title__title -->
                    </div><!-- /.sec-title -->
                </div><!-- /.contact-page__content-->
                <div class="contact-page__form">
                    <form action="assets/inc/sendemail.php" class="comments-form__form contact-form-validated form-one">
                        <div class="form-one__group">
                            <div class="form-one__control">
                                <input type="text" name="name" placeholder="Votre nom">
                            </div><!-- /.form-one__control -->
                            <div class="form-one__control" data-wow-duration="1500ms" data-wow-delay="50ms">
                                <input type="email" name="email" placeholder="Adresse e-mail">
                            </div><!-- /.form-one__control -->
                            <div class="form-one__control form-one__control--full">
                                <textarea name="message" placeholder="Écrivez votre message"></textarea>
                            </div><!-- /.form-one__control -->
                            <div class="form-one__control form-one__control--full">
                                <button type="submit" class="qizon-btn">
                                    Envoyer un message
                                </button>
                            </div><!-- /.form-one__control -->
                        </div><!-- /.form-one__group -->
                    </form><!-- /.comments-form__form -->
                </div><!-- /.contact-page__form-->
            </div><!-- /.container-->
        </section><!-- /.contact-page-->

        <section class="contact-infu">
            <div class="container">
                <div class="row gutter-y-30">
                    <div class="col-lg-4 col-md-6">
                        <div class="contact-infu__single wow fadeInUp" data-wow-duration='1500ms'
                            data-wow-delay='000ms'>
                            <a href="" class="contact-infu__icon">
                                <span class="icon-entrepreneur"></span>
                            </a>
                            <h4 class="contact-infu__title">À propos de OCDPCI</h4>
                            <p class="contact-infu__desc">Morbi ut tellus ac leo molestie luctus nec vehicula sed
                                justo onec
                                tempor rhoncus volutpat ras lorem.</p>
                        </div>
                    </div><!-- /.col-lg-4 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="contact-infu__single wow fadeInUp" data-wow-duration='1500ms'
                            data-wow-delay='200ms'>
                            <a href="" class="contact-infu__icon">
                                <span class="icon-location"></span>
                            </a>

                            <h4 class="contact-infu__title">Notre adresse</h4>
                            <p class="contact-infu__desc">66 Rue Broklyn, 600 New York. États-Unis d'Amérique
                                <br>
                                Boîte postale 0000
                            </p>
                        </div>
                    </div><!-- /.col-lg-4 -->
                    <div class="col-lg-4 col-md-6">
                        <div class="contact-infu__single wow fadeInUp" data-wow-duration='1500ms'
                            data-wow-delay='400ms'>
                            <a href="" class="contact-infu__icon">
                                <span class="icon-contact"></span>
                            </a>
                            <h4 class="contact-infu__title">Appelez ou écrivez</h4>
                            <p class="contact-infu__desc"> besoindeaide@entreprise.com
                                info@entreprise.com <br>
                                +92 (666) - 8800</p>
                        </div>
                    </div><!-- /.col-lg-4 -->
                </div><!-- /.row -->
            </div><!-- /.container-->
        </section><!-- /.contact-infu -->

        <section class="main-cta contact-page--cta wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
            <div class="main-cta__shape">
                <img src="assets/images/cta-shape.png" alt="">
                <p class="main-cta__shape__text">Résultats en <br>
                    quelques secondes</p>
            </div>
            <div class="container">
                <div class="main-cta__background" style="background-image: url(assets/images/ctabg.png);">
                </div><!-- /.cta-one__background-->
                <div class="main-cta__content">
                    <div class="main-cta__title">
                        <p>Votre histoire commence ici</p>
                        <h3>Prêt à lever des fonds pour une idée ?</h3>
                    </div>
                    <a href="" class="qizon-btn">
                        <span>Faites-le</span>
                    </a>
                </div><!-- /.cta-one__content-->
            </div><!-- /.container-->
        </section><!-- /.main-cta-one-->

        <section class="contact-map">
            <div class="container-fluid">
                <div class="google-map google-map__contact">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3972.1735774366775!2d-3.99099722460383!3d5.3904983945885245!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfc195e2f74377a7%3A0x7ccb705d620e599b!2sOrxane%20Event!5e0!3m2!1sfr!2sci!4v1733482329979!5m2!1sfr!2sci" width="600" 
                    height="450" style="border:0;" allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div> <!-- /.google-map -->
            </div><!-- /.container-fluid -->
        </section><!-- /.contact-map -->
@endsection
