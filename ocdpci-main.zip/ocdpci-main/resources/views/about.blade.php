@extends('layouts.app')
@section('content')
    <section class="page-header">
        <div class="page-header__bg" style="background-image: url(assets/images/page-header/page-header.jpg);">

        </div>
        <!-- /.page-header__bg -->
        <div class="page-header__shape">
            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
        </div>

        <div class="container">
            <ul class="qizon-breadcrumb list-unstyled">
                <li><a href="index.html">Home</a></li>
                <span>/</span>
                <li><span>About</span></li>
            </ul><!-- /.thm-breadcrumb list-unstyled -->
            <h2 class="page-header__title">ONCDP-CI</h2>
        </div><!-- /.container -->
    </section><!-- /.page-header -->


    <section class="about-two about-page__about section-space-top">
        <div class="container">
            <div class="row gutter-y-30">
                <div class="col-lg-6">
                    <div class="about-two__single wow fadeInLeft" data-wow-duration="1500ms">
                        <div class="about-two__image">
                            <div class="content-inner">
                                <img src="assets/images/about/dg.jpeg" alt="">
                            </div>
                        </div>
                    </div>
                </div><!-- /.col-lg-6 -->
                <div class="col-lg-6">
                    <div class="about-two__content wow fadeInRight" data-wow-duration="1500ms">
                        <div class="sec-title">
                            <h6 class="sec-title__tagline">Présentation</h6><!-- /.sec-title__tagline -->
                            <h2 class="sec-title__title"> Notre Mission</h2>
                            <!-- /.sec-title__title -->
                        </div><!-- /.sec-title -->
                        <div class="about-two__inner">
                            <div class="about-two__text">
                                <!--<h4 class="about-two__title">We help surface innovations in tech</h4>-->
                                <p class="about-two__desc">L'Observatoire National de la Communication Digitale Publique de
                                    Côte d'Ivoire (ONCDP-CI) est une institution dédiée au suivi, à l'analyse et à
                                    l'amélioration de la présence numérique des organismes publics ivoiriens. Notre mission
                                    est d'évaluer et de promouvoir l'excellence dans la communication digitale des
                                    institutions gouvernementales, des ministères et des collectivités locales.</p>
                            </div>

                            <div class="about-two__text">
                                <h4 class="about-two__title">Mot du Directeur général</h4>
                                <p class="about-two__desc">"Notre engagement envers l'excellence numérique du service public
                                    ivoirien guide chacune de nos actions.
                                    L'ONCDP-CI œuvre quotidiennement pour accompagner la transformation digitale de nos
                                    institutions, garantissant ainsi une communication plus efficace et transparente avec
                                    nos citoyens. Ensemble, construisons une administration publique moderne et connectée."
                                <p>
                                <h4>Guy Romain BRISSI</h4>
                                </p>



                                </p>
                            </div>
                            <!-- <div class="about-two__progress-box">
                                        <h4 class="progress-box__title">Investment Plan</h4>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="77%"
                                                style="width: 0;">
                                                <div class="progress-box__bar-number count-box">
                                                    <span class="count-text" data-stop="77" data-speed="1000">0</span>
                                                    <span>%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div><!-- /.about-two__progress-box-->
                            <!-- <div class="about-two__features-box">
                                        <div class="about-two__features">
                                            <div class="about-two__features-infu">
                                                <a href=""><span class="icon-confirmation"></span></a>
                                            </div>
                                            <p>Discover how to plan, create, and manage your crowdfunding campaign</p>
                                        </div>
                                        <div class="about-two__features">
                                            <div class="about-two__features-infu">
                                                <a href=""><span class="icon-confirmation"></span></a>
                                            </div>
                                            <p>Find our how to evaluate and back crowdfunding campaigns</p>
                                        </div>
                                    </div>
                                    <a href="" class="qizon-btn about-two__btn">
                                        <span>Discover More</span>
                                    </a>
                                </div>-->
                        </div><!-- /.about-two__content-->
                    </div><!-- /.col-lg-6 -->
                </div><!-- /.row -->
            </div><!-- /.container -->
    </section><!-- /.about-two -->


     {!! $aboutContent !!}


    <section class="video-two about-page__video">
        <div class="video-two__background jarallax">
        </div>
        <div class="container">
            <div class="video-two__content">
                <div class="video-two__action wow fadeInDown" data-wow-duration="1500ms">
                    <a href="https://www.youtube.com/watch?v=Nh-CtVgQNnA" class="popup-video video-popup">
                        <span><i class="fa-solid fa-play"></i></span>
                    </a>
                    <h2 class="video-two__title wow fadeInUp" data-wow-duration="1500ms">We help at you every <br>
                        step from concept to market</h2>
                </div><!-- /.video-two__action-->
            </div><!-- /.video-two__content -->
        </div><!-- /.container -->
    </section><!-- /.video-two about-page__video -->

    <section class="main-testimonial testimonial--one"
        style="background-image: url(assets/images/testimonial/testimonial-bg-shape.png);">
        <div class="main-testimonial__bg"></div>
        <div class="container">
            <div class="main-testimonial__wrapper">
                <div class="main-testimonial__left">
                    <div class="sec-title wow fadeInLeft" data-wow-duration="1500ms">
                        <h6 class="sec-title__tagline">testimonials
                        </h6><!-- /.sec-title__tagline -->

                        <h2 class="sec-title__title">
                            What they’re <br>
                            talking about?<!-- /.sec-title__title -->
                    </div><!-- /.sec-title -->
                    <div class="main-testimonial__reviews wow fadeInLeft" data-wow-duration="2000ms">
                        <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                        <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                        <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                        <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                        <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>

                    </div>
                    <p class="main-testimonial__reviews__text">
                        Trust score 4.5 (Based on 2,500 reviews)
                    </p>
                </div><!-- /.main-testimonial__left-->
                <div class="main-testimonial__right qizon-owl__carousel owl-carousel owl-theme wow fadeInRight"
                    data-wow-duration="1500ms"
                    data-owl-options='
                        { "items": 1,
                         "margin": 0,
                         "loop" :true,
                         "smartSpeed": 700,
                          "dots":false,
                          "autoplay":false,
                           "responsive" :  { "0" :

                         {
                            "items" : 1,
                           "margin" : 10
                         },

                         "991" :
                          {
                            "items" : 1,
                            "margin" :10
                        },
                        "992" : {
                            "items" : 1.2,
                            "margin" : 10
                        },
                        "1209" : {
                            "items" : 1.5,
                            "margin" : 30
                        },
                        "1440" : {
                            "items" : 1.9,
                            "margin" : 30
                        }
                    }
                    }'>

                    <div class="item">
                        <div class="main-testimonial__single">
                            <div class="main-testimonial__content">
                                <div class="main-testimonial__meta">
                                    <div class="main-testimonial__meta-left">
                                        <div class="main-testimonial__image">
                                            <img src="assets/images/testimonial/testimonialImg1.png" alt="">
                                            <span class="main-testimonial__quote-icon">“</span>
                                        </div>
                                    </div>
                                    <div class="main-testimonial__meta-right">
                                        <div class="main-testimonial__stars"> <i class="fa fa-star"></i> <i
                                                class="fa fa-star"></i> <i class="fa fa-star"></i> <i
                                                class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                        <h4 class="main-testimonial__name">Kevin martin</h4>
                                        <div class="main-testimonial__job">Crowd Company Founder</div>
                                    </div>
                                </div>
                                <div class="main-testimonial__quote"> I tried this smart piano and learned how to
                                    play
                                    music in a day. There are many variations of passages of lorem ipsum but the
                                    majority.</div>
                            </div>
                        </div>
                    </div><!-- /.item-->
                    <div class="item">
                        <div class="main-testimonial__single">
                            <div class="main-testimonial__content">
                                <div class="main-testimonial__meta">
                                    <div class="main-testimonial__meta-left">
                                        <div class="main-testimonial__image">
                                            <img src="assets/images/testimonial/testimonialImg2.png" alt="">
                                            <span class="main-testimonial__quote-icon">“</span>
                                        </div>
                                    </div>
                                    <div class="main-testimonial__meta-right">
                                        <div class="main-testimonial__stars"> <i class="fa fa-star"></i> <i
                                                class="fa fa-star"></i> <i class="fa fa-star"></i> <i
                                                class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                        <h4 class="main-testimonial__name">Jessica brown</h4>
                                        <div class="main-testimonial__job">Crowd Company Founder</div>
                                    </div>
                                </div>
                                <div class="main-testimonial__quote"> I tried this smart piano and learned how to
                                    play
                                    music in a day. There are many variations of passages of lorem ipsum but the
                                    majority.</div>
                            </div>
                        </div>
                    </div><!-- /.item-->
                    <div class="item">
                        <div class="main-testimonial__single">
                            <div class="main-testimonial__content">
                                <div class="main-testimonial__meta">
                                    <div class="main-testimonial__meta-left">
                                        <div class="main-testimonial__image">
                                            <img src="assets/images/testimonial/testimonialImg3.png" alt="">
                                            <span class="main-testimonial__quote-icon">“</span>
                                        </div>
                                    </div>
                                    <div class="main-testimonial__meta-right">
                                        <div class="main-testimonial__stars"> <i class="fa fa-star"></i> <i
                                                class="fa fa-star"></i> <i class="fa fa-star"></i> <i
                                                class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                        <h4 class="main-testimonial__name">Jessica brown</h4>
                                        <div class="main-testimonial__job">Crowd Company Founder</div>
                                    </div>
                                </div>
                                <div class="main-testimonial__quote"> I tried this smart piano and learned how to
                                    play
                                    music in a day. There are many variations of passages of lorem ipsum but the
                                    majority.</div>
                            </div>
                        </div>
                    </div><!-- /.item-->
                </div><!-- /.main-testimonial__right-->
            </div><!-- /.main-testimonial__wrapper-->
        </div><!-- /.container-->
    </section><!-- /.main-testimonial-->

    <section class="team">
        <div class="container">
            <div class="team__content">
                <div class="sec-title">
                    <h6 class="text-center sec-title__tagline">Testimonials</h6><!-- /.sec-title__tagline -->
                    <h2 class="text-center sec-title__title">What they’re talking?</h2><!-- /.sec-title__title -->
                </div><!-- /.sec-title -->
                <div class="row">
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-duration='1500ms'
                        data-wow-delay='00ms'>
                        <div class="team-card">
                            <div class="team-card__shape"></div>
                            <div class="team-card__details">
                                <div class="team-card__img">
                                    <img src="assets/images/team/teamImg1.png" alt="">
                                </div>
                                <div class="team-card__intro">
                                    <h3>Kevin Martin</h3>
                                    <p>Manager</p>
                                    <div class="team-card__social">
                                        <a href=""><i class="fa-brands fa-twitter"></i></a>
                                        <a href=""><i class="fa-brands fa-facebook"></i></a>
                                        <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.team-card -->
                    </div><!-- /.col-xl-4 col-lg-6 col-md-6 -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-duration='1500ms'
                        data-wow-delay='200ms'>
                        <div class="team-card">
                            <div class="team-card__shape"></div>
                            <div class="team-card__details">
                                <div class="team-card__img">
                                    <img src="assets/images/team/teamImg2.png" alt="">
                                </div>
                                <div class="team-card__intro">
                                    <h3>Aleesha Brown</h3>
                                    <p>Manager</p>
                                    <div class="team-card__social">
                                        <a href=""><i class="fa-brands fa-twitter"></i></a>
                                        <a href=""><i class="fa-brands fa-facebook"></i></a>
                                        <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.team-card -->
                    </div><!-- /.col-xl-4 col-lg-6 col-md-6 -->
                    <div class="col-xl-4 col-lg-6 col-md-6 wow fadeInUp" data-wow-duration='1500ms'
                        data-wow-delay='400ms'>
                        <div class="team-card">
                            <div class="team-card__shape"></div>
                            <div class="team-card__details">
                                <div class="team-card__img">
                                    <img src="assets/images/team/teamImg3.png" alt="">
                                </div>
                                <div class="team-card__intro">
                                    <h3>David Cooper</h3>
                                    <p>Manager</p>
                                    <div class="team-card__social">
                                        <a href=""><i class="fa-brands fa-twitter"></i></a>
                                        <a href=""><i class="fa-brands fa-facebook"></i></a>
                                        <a href=""><i class="fa-brands fa-instagram"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.team-card -->
                    </div><!-- /.col-xl-4 col-lg-6 col-md-6 -->
                </div><!-- /.row -->
            </div><!-- /.team__content -->
        </div><!-- /.container -->
    </section><!-- /.team -->

    <section class="brand-two">
        <div class="container">
            <div class="brand-two__slider qizon-owl__carousel owl-carousel owl-theme"
                data-owl-options='{
                "items": 1,
                "margin": 0,
                "loop": true,
                "smartSpeed": 700,
                "nav": false,
                "navText": ["<span class=\"icon-arrow-left\"></span>","<span class=\"icon-arrow-right\"></span>"],
                "dots": false,
                "autoplay": true,
                "responsive": {
                    "0":{
                        "items": 2,
                        "margin": 50
                    },
                    "500":{
                        "items": 3,
                        "margin": 70
                    },
                    "768":{
                        "items": 4,
                        "margin": 70
                    },
                    "992":{
                        "items": 5,
                        "margin": 100
                    },
                    "1200":{
                        "items": 5,
                        "margin": 140
                    }
                }
            }'>
                <div class="brand-two__slider__item">
                    <img src="assets/images/brand/brand-logo-two.png" alt="brand logo">
                </div><!-- /.owl-slide-item-->
                <div class="brand-two__slider__item">
                    <img src="assets/images/brand/brand-logo-two.png" alt="brand logo">
                </div><!-- /.owl-slide-item-->
                <div class="brand-two__slider__item">
                    <img src="assets/images/brand/brand-logo-two.png" alt="brand logo">
                </div><!-- /.owl-slide-item-->
                <div class="brand-two__slider__item">
                    <img src="assets/images/brand/brand-logo-two.png" alt="brand logo">
                </div><!-- /.owl-slide-item-->
                <div class="brand-two__slider__item">
                    <img src="assets/images/brand/brand-logo-two.png" alt="brand logo">
                </div><!-- /.owl-slide-item-->
            </div><!-- /.thm-owl__slider -->
        </div><!-- /.container -->
    </section><!-- /.brand-two -->
@endsection
