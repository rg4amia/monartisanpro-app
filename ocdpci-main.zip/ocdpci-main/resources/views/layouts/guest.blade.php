<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('app.name', 'Laravel') }} - Authentification</title>

    <!-- CSS Files -->
    <link rel="stylesheet" href="{{ asset('Modernize-1.0.0/assets/css/styles.min.css') }}">
</head>

<body>
    @yield('content')

    <!-- JS Files -->
    <script src="{{ asset('Modernize-1.0.0/assets/libs/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('Modernize-1.0.0/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
</body>

</html>
