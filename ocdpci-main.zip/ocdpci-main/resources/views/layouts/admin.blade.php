<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>

    <!-- CSS Files -->
    <link rel="stylesheet" href="{{ asset('Modernize-1.0.0/assets/css/styles.min.css') }}">
</head>

<body>
    <!--  Body Wrapper -->
    <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full">
        <!-- Sidebar Start -->
        @include('layouts.partials.sidebar')

        <!--  Main wrapper -->
        <div class="body-wrapper">
            <!-- Header Start -->
            @include('layouts.partials.header')

            <!--  Container Main -->
            <div class="container-fluid">
                @yield('content')
            </div>
        </div>
    </div>

    <!-- JS Files -->
    <script src="{{ asset('Modernize-1.0.0/assets/libs/jquery/dist/jquery.min.js') }}"></script>
    <script src="{{ asset('Modernize-1.0.0/assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('Modernize-1.0.0/assets/js/sidebarmenu.js') }}"></script>
    <script src="{{ asset('Modernize-1.0.0/assets/js/app.min.js') }}"></script>
</body>

</html>
