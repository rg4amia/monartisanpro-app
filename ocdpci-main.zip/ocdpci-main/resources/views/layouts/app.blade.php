<!DOCTYPE html>
<html lang="en">
<head>
    @include('includes.head')
</head>
<body class="custom-cursor">
    @include('includes.preloader')

    <div class="page-wrapper">
        @include('includes.topbar')
        @include('includes.header')

        @yield('content')

        @include('includes.footer')
        @include('includes.mobile-nav')
        @include('includes.search-popup')
    </div>

    @include('includes.scripts')
</body>
</html>
