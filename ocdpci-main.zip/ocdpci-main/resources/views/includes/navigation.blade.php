<div class="main-header__inner__left">
    <nav class="main-header__nav main-menu">
        <ul class="main-menu__list">
            <li>
                <a href="{{ route('about') }}" style="color: var(--qizon-primary);">A propos</a>
            </li>
             <li>
                <a href="#" style="color: var(--qizon-primary);">Tous</a>
            </li>
            <li class="menu-item-has-children">
                <a href="#" style="color: var(--qizon-primary);">Secteur Public</a>
                <ul class="sub-menu">
                    <li><a href="{{ route('projects.institutions') }}" style="color: var(--qizon-primary);">Institutions de la république</a></li>
                    <li><a href="{{ route('projects.ministeres') }}" style="color: var(--qizon-primary);">Ministères</a></li>
                    <li><a href="{{ route('projects.districts') }}" style="color: var(--qizon-primary);">Districts Autonomes</a></li>
                    <li><a href="{{ route('projects.conseils-regionales') }}" style="color: var(--qizon-primary);">Conseils Régionaux</a></li>
                    <li><a href="{{ route('projects.communes') }}" style="color: var(--qizon-primary);">Communes</a></li>
                    <li><a href="{{ route('projects.ambassades') }}" style="color: var(--qizon-primary);">Ambassades de Côte d'Ivoire</a></li>
                    <li><a href="{{ route('projects.centrale-syndicales') }}" style="color: var(--qizon-primary);">Centrales Syndicales</a></li>
                </ul>
            </li>
            <li class="menu-item-has-children">
                <a href="#" style="color: var(--qizon-primary);">Secteur Privé</a>
                <ul class="sub-menu">
                    <li><a href="{{ route('projects.tres-grande-entreprise') }}" style="color: var(--qizon-primary);">Très Grande Entreprise</a></li>
                    <li><a href="{{ route('projects.grande-entreprise') }}" style="color: var(--qizon-primary);">Grandes Entreprise</a></li>
                    <li><a href="{{ route('projects.moyenne-entreprise') }}" style="color: var(--qizon-primary);">Moyennes Entreprises</a></li>
                    <li><a href="{{ route('projects.petite-entreprise') }}" style="color: var(--qizon-primary);">Petites Entreprises</a></li>
                    <li><a href="{{ route('projects.groupements-professionnels') }}" style="color: var(--qizon-primary);">Groupements Professionnels</a></li>
                    <li><a href="{{ route('projects.associations-professionnels') }}" style="color: var(--qizon-primary);">Association Professionnels</a></li>
                </ul>
            </li>
            <li>
                <a href="#" style="color: var(--qizon-primary);">Statistique</a>
            </li>
            <li>
                <a href="#" style="color: var(--qizon-primary);">Agenda</a>
            </li>
            <li>
                <a href="#" style="color: var(--qizon-primary);">Top Info</a>
            </li>
            <li>
                <a href="#" style="color: var(--qizon-primary);">Nos partenaires</a>
            </li>
        </ul>
    </nav>
</div>
