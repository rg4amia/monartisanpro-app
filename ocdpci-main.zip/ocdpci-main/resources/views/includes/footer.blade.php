<footer class="main-footer" style="background-color: rgb(82, 80, 80); color: white;">
    <div class="container">
        <div class="row gutter-y-30">
            <div class="col-lg-5 col-xl-3 col-md-8 wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='00ms'>
                <div class="main-footer__left">
                    <div class="footer-logo">
                         <img src="{{ asset('assets/Logo.png') }}" alt="Logo">
                    </div>
                    <p>Abidjan, Côte d'Ivoire</p>
                    <div class="main-footer__contact">
                        <li><i class="fa-solid fa-envelope"></i><a href="mailto:contact@ocdpci.ci">contact@ocdpci.ci</a></li>
                        <li><i class="fa-solid fa-phone"></i><a href="tel:+225 0748159797">+225 0748159797</a></li>
                    </div>
                    <div class="main-footer__social-icon">
                        <a href="#"><i class="fa-brands fa-twitter"></i></a>
                        <a href="#"><i class="fa-brands fa-facebook"></i></a>
                        <a href="#"><i class="fa-brands fa-pinterest-p"></i></a>
                        <a href="#"><i class="fa-brands fa-instagram"></i></a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-xl-2 col-md-4 wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='200ms'>
                <div class="main-footer__navmenu">
                    <div class="main-footer__navmenu-title">
                        <h5>Menu</h5>
                    </div>
                    <div class="main-footer__nammenu-list">
                        <ul>
                            <li><a href="{{ route('projects.institutions') }}" style="color: var(--qizon-secondary);">Institutions</a></li>
                            <li><a href="{{ route('projects.ministeres') }}" style="color: var(--qizon-secondary);">Ministères</a></li>
                            <li><a href="{{ route('projects.districts') }}" style="color: var(--qizon-secondary);">Districts Autonomes</a></li>
                            <li><a href="{{ route('projects.communes') }}" style="color: var(--qizon-secondary);">Communes</a></li>
                            <li><a href="{{ route('projects.conseils-regionales') }}" style="color: var(--qizon-secondary);">Conseils Régionaux</a></li>
                            <li><a href="{{ route('contact') }}" style="color: var(--qizon-secondary);">Contact</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-xl-2 col-md-3 wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='400ms'>
                {{-- <div class="main-footer__navmenu">
                    <div class="main-footer__navmenu-title">
                        <h5>Fundraising</h5>
                    </div>
                    <div class="main-footer__nammenu-list">
                        <ul>
                            <li><a href="#" style="color: var(--qizon-secondary);">Design</a></li>
                            <li><a href="#" style="color: var(--qizon-secondary);">Education</a></li>
                            <li><a href="#" style="color: var(--qizon-secondary);">How it Works</a></li>
                            <li><a href="#" style="color: var(--qizon-secondary);">Technology</a></li>
                            <li><a href="#" style="color: var(--qizon-secondary);">Fashion</a></li>
                            <li><a href="#" style="color: var(--qizon-secondary);">Film & Video</a></li>
                        </ul>
                    </div>
                </div> --}}
            </div>
            <div class="col-lg-7 col-xl-5 col-md-9 wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='600ms'>
                <div class="main-footer__newsletter">
                    <h3>Newsletter</h3>
                    <p>Subscribe to our newsletter to get our daily latest news and updates</p>
                    <div class="main-footer__input">
                        <input type="text" placeholder="Email address">
                        <a href="#" class="main-footer__icon"><i class="fa-solid fa-location-arrow"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="main-footer__bottom">
        <div class="container">
            <div class="main-footer__bottom__inner">
                <p class="main-footer__copyright">
                    &copy; Copyright <span class="dynamic-year">{{ date('Y') }}</span> by Company.com
                </p>
            </div>
        </div>
    </div>
</footer>
