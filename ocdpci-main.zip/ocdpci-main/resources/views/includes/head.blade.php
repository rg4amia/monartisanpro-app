<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="robots" content="index, follow" />

{{-- ONCD (Observatoire National de la Communication Digitale) --}}
<title>{{ $pageTitle ?? 'ONCD - Observatoire National de la Communication Digitale en Côte d\'Ivoire' }}</title>

<!-- SEO Meta Tags -->
<meta name="description" content="{{ $metaDescription ?? 'Observatoire National de la Communication Digitale (ONCD) - Analyse et suivi de la communication digitale en Côte d\'Ivoire' }}" />
<meta name="keywords" content="ONCD, communication digitale, Côte d'Ivoire, observatoire, analyse web, médias numériques" />
<meta name="author" content="ONCD" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:url" content="{{ url('/') }}" />
<meta property="og:title" content="{{ $pageTitle ?? 'ONCD - Observatoire National de la Communication Digitale' }}" />
<meta property="og:description" content="{{ $metaDescription ?? 'Analyse et suivi de la communication digitale en Côte d\'Ivoire' }}" />
<meta property="og:image" content="{{ asset('assets/Logo.png') }}" />

<!-- Twitter -->
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:url" content="{{ url('/') }}" />
<meta name="twitter:title" content="{{ $pageTitle ?? 'ONCD - Observatoire National de la Communication Digitale' }}" />
<meta name="twitter:description" content="{{ $metaDescription ?? 'Analyse et suivi de la communication digitale en Côte d\'Ivoire' }}" />
<meta name="twitter:image" content="{{ asset('assets/Logo.png') }}" />

<!-- favicons Icons -->
<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('assets/images/favicons/apple-touch-icon.png') }}" />
<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('assets/Logo.png') }}" />
<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/Logo.png') }}" />
<link rel="manifest" href="{{ asset('assets/images/favicons/site.webmanifest') }}" />

<!-- Canonical Link -->
<link rel="canonical" href="{{ url()->current() }}" />

<!-- Language -->
<link rel="alternate" hreflang="fr" href="{{ url()->current() }}" />

<!-- fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Lexend+Deca:wght@100..900&display=swap" rel="stylesheet">

<!-- CSS Files -->
<link rel="stylesheet" href="{{ asset('assets/vendors/bootstrap/css/bootstrap.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/bootstrap-select/bootstrap-select.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/animate/animate.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/fontawesome/css/all.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/jquery-ui/jquery-ui.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/jarallax/jarallax.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/jquery-magnific-popup/jquery.magnific-popup.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/nouislider/nouislider.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/nouislider/nouislider.pips.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/tiny-slider/tiny-slider.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/qizon-icon/style.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/owl-carousel/css/owl.carousel.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/owl-carousel/css/owl.theme.default.min.css') }}" />
<link rel="stylesheet" href="{{ asset('assets/vendors/swiper/css/swiper-bundle.min.css') }}" />

<!-- DataTable Css-->
<link rel="stylesheet" href="https://cdn.datatables.net/2.2.1/css/dataTables.dataTables.min.css" />

<!-- template styles -->
<link rel="stylesheet" href="{{ asset('assets/css/qizon.css') }}" />
