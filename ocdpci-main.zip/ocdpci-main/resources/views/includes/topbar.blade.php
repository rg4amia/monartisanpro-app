<section class="topbar topbar--one">
    <div class="container">
        <div class="topbar__wrapper">
            <div class="topbar__left">
                <div class="main-header__logo">
                    <a href="{{ route('home') }}">
                        <img src="{{ asset('assets/Logo.png') }}" alt="Logo" height="69">
                    </a>
                </div>
                <div class="search-toggler main-header__search">
                    <a href="#" class="search__icon">
                        <span class="icon-search-interface-symbol"></span>
                    </a>
                    <span class="search-here">Search here</span>
                </div>
            </div>
            <div class="topbar__right">
                <div class="topbar__infu pr-22">
                    <a href="mailto:contact@ocdpci.ci" class="topbar__infu__icon">
                        <i class="fa-regular fa-envelope"></i>
                    </a>
                    <div class="topbar__infu__text">
                        <span>Envoyer un mail</span>
                        <span class="topbar__contact">contact@ocdpci.ci</span>
                    </div>
                </div>
                <div class="topbar__infu">
                    <a href="tel:+225 0748159797" class="topbar__infu__icon">
                        <i class="fa-solid fa-phone"></i>
                    </a>
                    <div class="topbar__infu__text">
                        <span>Contactez-nous</span>
                        <span class="topbar__contact">+225 0748159797</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
