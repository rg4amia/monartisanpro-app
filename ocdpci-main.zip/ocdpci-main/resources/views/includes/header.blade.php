<header class="main-header main-header--one sticky-header sticky-header--normal">
    <div class="main-header__wrappper">
        <div class="main-header__logo__sticky">
            <a href="{{ route('home') }}">
                <img src="{{ asset('assets/Logo.png') }}" alt="Logo">
            </a>
        </div>
        <div class="container">
            <div class="main-header__inner">
                <div class="mobile-nav__btn mobile-nav__toggler">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>

                @include('includes.navigation')

                {{-- <div class="main-header__inner__right">
                    <div class="main-header__user-profile">
                        <a href="#" class="main-header__user-profile__avater">
                            <span class="icon-account"></span>
                        </a>
                        <a href="#" class="main-header__user-profile__text">Connexion</a>
                        <span class="main-header__user-profile__br">/</span>
                        <a href="#" class="main-header__user-profile__text">S'enregistrer</a>

                        <a href="{{ route('contact') }}" class="qizon-btn main-menu__btn">
                            <i class="fa-solid fa-circle-plus"></i>
                            <span>Faire un don</span>
                        </a>
                    </div>
                </div> --}}
            </div>
        </div>
    </div>
</header>
