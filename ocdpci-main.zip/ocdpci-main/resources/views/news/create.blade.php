@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Créer une nouvelle actualité</h1>

        <form action="{{ route('news.store') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="title">Titre</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>

            <div class="form-group">
                <label for="content">Contenu</label>
                <textarea class="form-control" id="content" name="content" rows="5" required></textarea>
            </div>

            <div class="form-group">
                <label for="image">Image</label>
                <input type="file" class="form-control-file" id="image" name="image" accept="image/*">
            </div>

            <div class="form-group">
                <label for="publication_date">Date de publication</label>
                <input type="date" class="form-control" id="publication_date" name="publication_date" required>
            </div>

            <button type="submit" class="btn btn-primary">Publier</button>
        </form>
    </div>
@endsection
