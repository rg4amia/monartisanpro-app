@extends('layouts.app')

@section('content')
    <h1>News Details</h1>
@endsection
