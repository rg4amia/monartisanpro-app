@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Nos Actualités</h1>

        @if (auth()->check())
            <a href="{{ route('news.create') }}" class="btn btn-primary mb-3">Créer une nouvelle actualité</a>
        @endif

        <div class="row">
            @foreach ($news as $article)
                <div class="col-md-4 mb-4">
                    <div class="card">
                        @if ($article->image)
                            <img src="{{ asset('storage/' . $article->image) }}" class="card-img-top"
                                alt="{{ $article->title }}">
                        @endif
                        <div class="card-body">
                            <h5 class="card-title">{{ $article->title }}</h5>
                            <p class="card-text">{{ Str::limit($article->content, 100) }}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted">Publié le
                                    {{ $article->publication_date->format('d/m/Y') }}</small>
                                <a href="{{ route('news.show', $article) }}" class="btn btn-sm btn-outline-secondary">Lire
                                    plus</a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        {{ $news->links() }}
    </div>
@endsection
