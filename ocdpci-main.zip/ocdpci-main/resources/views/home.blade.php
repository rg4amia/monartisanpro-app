@extends('layouts.app')
@section('content')
    {!! $heroSliderContent !!}

    {!! $campaignContent !!}

    <section class="statistics-one section-space-top">
        <div class="container">
            <div class="text-center sec-title">
                <h6 class="sec-title__tagline">Nos Statistiques</h6>
                <h2 class="sec-title__title">Aperçu de Notre Impact</h2>
            </div>
            <div class="row">
                <div class="col-md-3 col-sm-6">
                    <div class="statistics-one__single wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                        <div class="statistics-one__icon">
                            <span class="icon-success"></span>
                        </div>
                        <div class="statistics-one__content">
                            <h3 class="statistics-one__count count-box">
                                {{--  <span class="count-text" data-stop="150" data-speed="1500">0</span> --}}
                                <span style="font-size: 20px;">40/150 Mairies</span>
                            </h3>
                            <h4 class="statistics-one__title">Couverture Numérique</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="statistics-one__single wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='300ms'>
                        <div class="statistics-one__icon">
                            <span class="icon-human-resources"></span>
                        </div>
                        <div class="statistics-one__content">
                            <h3 class="statistics-one__count count-box">
                                <span class="count-text" data-stop="95" data-speed="1500">0</span>
                                <span>%</span>
                            </h3>
                            <h4 class="statistics-one__title">Taux de Satisfaction</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="statistics-one__single wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='600ms'>
                        <div class="statistics-one__icon">
                            <span class="icon-budget"></span>
                        </div>
                        <div class="statistics-one__content">
                            <h3 class="statistics-one__count count-box">
                                <span class="count-text" data-stop="36" data-speed="1500">0</span>
                                <span>+</span>
                            </h3>
                            <h4 class="statistics-one__title">Années d'Expérience</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6">
                    <div class="statistics-one__single wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='900ms'>
                        <div class="statistics-one__icon">
                            <span class="icon-success"></span>
                        </div>
                        <div class="statistics-one__content">
                            <h3 class="statistics-one__count count-box">
                                <span class="count-text" data-stop="250" data-speed="1500">0</span>
                                <span>+</span>
                            </h3>
                            <h4 class="statistics-one__title">Clients Satisfaits</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    {!! $ourBeenfitContent !!}

    <div class="clearfix"></div>

    {{-- {!! $categoriesContent !!} --}}

    {!! $campaignTwoContent !!}

    {!! $newsContent !!}

    <section class="main-news news-page section-space-top">
    <div class="container">
        <div class="sec-title">
            <h6 class="text-center sec-title__tagline">
                Liens Utiles
            </h6><!-- /.sec-title__tagline -->
            <h2 class="text-center sec-title__title">
                Liens Utiles
            </h2>
            <!-- /.sec-title__title -->
        </div><!-- /.sec-title -->
        <div class="main-news__inner">
            <div class="row gutter-y-30">
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="000ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://civ.abidjan.net/" target="_blank">Abidjan.net</a>
                                </h3>
                                <a class="main-news__bottom" href="https://civ.abidjan.net/" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="300ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 300ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://ci.ambafrance.org/-Francais-" target="_blank">Ambassade de France</a>
                                </h3>
                                <a class="main-news__bottom" href="https://ci.ambafrance.org/-Francais-" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="600ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 600ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://ci.usembassy.gov/fr/" target="_blank">Ambassade des États-Unis</a>
                                </h3>
                                <a class="main-news__bottom" href="https://ci.usembassy.gov/fr/" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="900ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 900ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://www.rti.ci/rti1" target="_blank">RTI Côte d'Ivoire</a>
                                </h3>
                                <a class="main-news__bottom" href="https://www.rti.ci/rti1" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="1200ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 1200ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://primature.ci/" target="_blank">Primature</a>
                                </h3>
                                <a class="main-news__bottom" href="https://primature.ci/" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="1500ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 1500ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://uvicoci.com/index.php/communes/#" target="_blank">UVICOCI</a>
                                </h3>
                                <a class="main-news__bottom" href="https://uvicoci.com/index.php/communes/#" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6">
                    <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                        data-wow-delay="1800ms"
                        style="visibility: visible; animation-duration: 1500ms; animation-delay: 1800ms; animation-name: fadeInUp;">
                        <div class="main-news__content">
                            <div class="main-news__content-inner">
                                <h3 class="main-news__title">
                                    <a href="https://cgeci.com/" target="_blank">CGECI</a>
                                </h3>
                                <a class="main-news__bottom" href="https://cgeci.com/" target="_blank">
                                    <span class="main-news__read-more">Visiter</span>
                                    <span class="main-news__arrow">
                                        <i class="fas fa-chevron-right"></i>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
