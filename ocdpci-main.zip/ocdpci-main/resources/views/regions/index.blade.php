@extends('layouts.admin')

@section('content')
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-4">Régions</h5>

                <a href="{{ route('regions.create') }}" class="btn btn-primary mb-3">
                    Ajouter une Région
                </a>

                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Slug</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($regions as $region)
                                <tr>
                                    <td>{{ $region->name }}</td>
                                    <td>{{ $region->slug }}</td>
                                    <td>{{ $region->email }}</td>
                                    <td>{{ $region->phone }}</td>
                                    <td>
                                        <a href="{{ route('regions.edit', $region) }}" class="btn btn-sm btn-warning">
                                            Éditer
                                        </a>
                                        <form action="{{ route('regions.destroy', $region) }}" method="POST"
                                            class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger"
                                                onclick="return confirm('Êtes-vous sûr ?')">
                                                Supprimer
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{ $regions->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection
