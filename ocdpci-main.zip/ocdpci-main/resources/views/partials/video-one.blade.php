  <section class="video-one">
            <div class="video-one__bg jarallax"></div>
            <div class="video-one__bg-overlay"></div><!-- /.video-one__bg-overlay-->
            <div class="container">
                <div class="video-one__title">
                    <h6 class="video-one__title__subtitle wow fadeInRight" data-wow-duration="1500ms">We’re Focused on
                        Results</h6>
                    <h2 class="video-one__title__title wow fadeInLeft" data-wow-duration="1500ms">
                        <span>The New Tech</span>
                        <span>That Get People</span>
                        <span>Talking</span>
                    </h2>
                    <a href="" class="qizon-btn video-one__btn wow fadeInUp" data-wow-duration="1500ms">
                        <span>Start a Project</span>
                    </a>
                </div><!-- /.video-one__title-->
                <div class="video-one__action wow fadeInUp" data-wow-duration="1500ms">
                    <a href="https://www.youtube.com/watch?v=Nh-CtVgQNnA" class="popup-video video-popup">
                        <span><i class="fa-solid fa-play"></i></span>
                    </a>
                </div><!-- /.video-one__action-->
            </div><!-- /.container-->
        </section><!-- /.video-one-->
