<section class="about-one section-space-top">
    <div class="about-one__background-overlay"></div><!-- /.about-one__background-overlay -->
    <div class="about-one__background-overlay-two">
        <img src="assets/images/about/about-bg-two.png" alt="">
    </div><!-- /.about-one__background-overlay -->
    <div class="container">
        <div class="row">
            <div class="col-lg-6 wow fadeInLeft" data-wow-duration="1500ms">
                <div class="about-one__image">
                    <div class="about-one__image__inner">
                        <div class="about-one__image__one">
                            <img src="{{ asset('assets/images/about/office-932926_1280.jpg') }}" alt="about image">
                            <div class="about-one__image__content count-box">
                                <h3 class="experiance-count count-text" data-stop="36" data-speed="1000">0</h3>
                                <h5 class="experiance-title">
                                    <span>Année d'</span>
                                    <span>expérience</span>
                                </h5>
                            </div>
                        </div><!-- /.about-one__image__one -->
                        <div class="about-one__image__two">
                            <img src="{{ asset('assets/images/about/web-design-1080730_1280.jpg') }}" alt="">
                        </div><!-- /.about-one__image__two-->
                    </div>
                </div>
            </div><!-- /.col-lg-6 -->
            <div class="col-lg-6 wow fadeInRight" data-wow-duration="1500ms">
                <div class="about-one__content">
                    <div class="sec-title">
                        <h6 class="sec-title__tagline">
                            Viste institutionnel
                        </h6><!-- /.sec-title__tagline -->
                        <h2 class="sec-title__title"> Notre Mission</h2><!-- /.sec-title__title -->
                    </div><!-- /.sec-title -->
                    <p class="about-one__text">Web designing in a powerful way of just not an only professions,
                        however, in a passion for our Company. We have to a tendency to believe the idea that
                        smart looking of any website is the first impression on visitors.</p>
                    <!-- /.about-one__text -->
                    <div class="about-one__inner">
                        <div class="about-one__left">
                            <div class="about-one__features">
                                <a href="" class="about-one__icon">
                                    <span class="icon-success"></span>
                                </a>
                                <div class="about-one__features__text">
                                    <h5>Suivie et evaluation</h5>
                                    <p>
                                        Nous suivons et évaluons les résultats.
                                    </p>
                                </div>
                            </div>
                            <div class="about-one__features__line"></div>
                            <div class="about-one__features">
                                <a href="" class="about-one__icon">
                                    <span class="icon-budget"></span>
                                </a>
                                <div class="about-one__features__text">
                                    <h5>Analyse et promotion</h5>
                                    <p>
                                        Nous analysons les données et promouvons les résultats.
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="about-one__right">
                            <div class="about-one__icon-box">
                                <a href="">
                                    <span class="icon-human-resources"></span>
                                </a>
                                <h6 class="about-one__icon-box__text">
                                    Empower
                                    people to
                                    unite around
                                    the idea
                                </h6>
                            </div>
                        </div>
                    </div>
                    <a href="about.html" class="qizon-btn about__btn">
                        <span>Discover More</span>
                    </a>
                </div>
            </div><!-- /.col-lg-6 -->
        </div><!-- /.row -->
    </div><!-- /.container -->
</section><!-- /.about-one -->
