<section class="categories-one">
            <div class="categories-one__bg-overlay"></div><!-- /.feature-one__bg-overlay-->
            <div class="categories-one__cart__inner">
                <div class="categories-one__cart__wrapper qizon-owl__carousel owl-carousel" data-owl-options='{
                    "items": 1,
                    "margin": 0,
                    "loop": true,
                    "autoplay": true,
                    "smartSpeed": 700,
                    "nav": false,
                    "navText": ["<span class=\"icon-arrow-left\"></span>","<span class=\"icon-arrow-right\"></span>"],
                    "dots": true,
                    "responsive": {
                        "0": {
                            "items": 1,
                            "nav": true,
                            "dots": false,
                            "margin": 0
                        },
                        "361": {
                            "items": 1,
                            "nav": true,
                            "dots": false,
                            "margin": 0
                        },
                        "550": {
                            "items": 2,
                            "margin": 20
                        },
                        "600": {
                            "items": 2,
                            "margin": 20
                        },

                        "800": {
                            "items": 3,
                            "margin": 20
                        },

                        "992": {
                            "items": 4,
                            "margin": 20
                        },
                        "1250": {
                            "items": 5,
                            "loop": false,
                            "margin": 20

                        }

                    }
                }'>
                    <div class="categories-one__cart item wow fadeInUp" data-wow-duration="1500ms"
                        data-wow-delay="00ms">
                        <div class="categories-one__cart__icon">
                            <h4>01</h4>
                            <a href="">
                                <span class="icon-cyborg"></span>
                            </a>
                        </div>
                        <h5 class="categories-one__cart__text">Institution</h5>
                    </div><!-- /.categories-one__cart-->
                    <div class="categories-one__cart item wow fadeInUp" data-wow-duration="1500ms"
                        data-wow-delay="200ms">
                        <div class="categories-one__cart__icon">
                            <h4>02</h4>
                            <a href="">
                                <span class="icon-reading-book"></span>
                            </a>
                        </div>
                        <h5 class="categories-one__cart__text">Ministères</h5>
                    </div><!-- /.categories-one__cart -->
                    <div class="categories-one__cart item wow fadeInUp" data-wow-duration="1500ms"
                        data-wow-delay="400ms">
                        <div class="categories-one__cart__icon">
                            <h4>03</h4>
                            <a href="">
                                <span class="icon-fashion"></span>
                            </a>
                        </div>
                        <h5 class="categories-one__cart__text">Districts</h5>
                    </div><!-- /.categories-one__cart -->
                    <div class="categories-one__cart item wow fadeInUp" data-wow-duration="1500ms"
                        data-wow-delay="600ms">
                        <div class="categories-one__cart__icon">
                            <h4>04</h4>
                            <a href="">
                                <span class="icon-medical"></span>
                            </a>
                        </div>
                        <h5 class="categories-one__cart__text">Commune</h5>
                    </div><!-- /.categories-one__cart -->
                    <div class="categories-one__cart item wow fadeInUp" data-wow-duration="1500ms"
                        data-wow-delay="800ms">
                        <div class="categories-one__cart__icon">
                            <h4>05</h4>
                            <a href="">
                                <span class="icon-design"></span>
                            </a>
                        </div>
                        <h5 class="categories-one__cart__text">Conseils régionales</h5>
                    </div><!-- /.categories-one__cart -->
                </div><!-- /.categories-one__cart__wrapper -->
                <div class="categories-one__title"><span>Explorer les plateformes digitales</span></div>
                <div class="features-one">
                    <img src="assets/images/futures/features-img1.png" alt="" class="wow fadeInLeft"
                        data-wow-duration="1500ms">
                    <h6 class="features-one__avater__text wow fadeInRight" data-wow-duration="1500ms">
                        <div class="features-one__title">Trouvez ici</div>
                        <div class="features-one__avater__heading">Une éventail digtal institutionel de
                            <span>3500 site internet</span>
                        </div>
                    </h6>
                </div><!-- /.categories-one__avater -->
            </div><!-- /.categories-one__cart__inner -->

        </section><!-- /.categories-one -->
