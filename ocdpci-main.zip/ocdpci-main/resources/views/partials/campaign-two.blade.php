<section class="campaign-two section-space-top">
            <div class="campaign-two__background"></div>
            <!-- /.campaign-two__background -->
            <div class="container">
                <div class="campaign-two__wrapper wow fadeInUp" data-wow-duration="1500ms">
                    <div class="sec-title">
                        <h6 class="text-center sec-title__tagline wow fadeInLeft" data-wow-duration="2000ms">Agenda
                        </h6><!-- /.sec-title__tagline -->
                        <h2 class="text-center sec-title__title wow fadeInRight" data-wow-duration="2000ms">Agenda de  l'observatoire</h2><!-- /.sec-title__title -->
                    </div><!-- /.sec-title -->
                    <div class="campaign-two__slider qizon-owl__carousel owl-carousel owl-theme pt-30" data-owl-options='{
                        "items": 1,
                        "margin": 0,
                        "loop": true,
                        "smartSpeed": 700,
                        "dots": true,
                        "nav": false,
                        "autoplay": true,
                        "responsive": {
                            "0": {
                                "items": 1,
                                "margin": 10
                            },
                            "768": {
                                "items": 1,
                                "margin": 30
                            },
                            "991": {
                                "items": 1,
                                "margin": 30
                            },
                            "992": {
                                "items": 2,
                                "margin": 30
                            }

                        }
                    }'>
                        <div class="item">
                            <div class="campaign-two__single">
                                <div class="campaign-two__image">
                                    <img src="assets/images/campaign/campaign-twoImg1.png" alt="">
                                </div>
                                <div class="campaign-two__content">
                                    <div class="cpamign-two__overlay"></div>
                                    <div class="campaign-two__time-remaining">
                                        <div class="time-remaining">
                                            <i class="fa-solid fa-clock"></i>
                                            <span class="time-remaining-desc">275</span>
                                            <span class="time-remaining-name">days Remaining</span>
                                        </div>
                                    </div>
                                    <h4 class="campaign-two__title">
                                        Formation à l'inteligence artificielle
                                    </h4>
                                    <div class="progress-box">
                                        <div class="progress-box__bar-text">Raised</div>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="70%"
                                                style="width: 0%;">
                                            </div>
                                        </div>
                                        <div class="progress-box__bar-number count-box">
                                            <span class="count-text" data-stop="70" data-speed="1000">0</span>
                                            <span>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="campaign-two__single">
                                <div class="campaign-two__image">
                                    <img src="assets/images/campaign/campaign-twoImg2.png" alt="">
                                </div>
                                <div class="campaign-two__content">
                                    <div class="cpamign-two__overlay"></div>
                                    <div class="campaign-two__time-remaining">
                                        <div class="time-remaining">
                                            <i class="fa-solid fa-clock"></i>
                                            <span class="time-remaining-desc">275</span>
                                            <span class="time-remaining-name">days Remaining</span>
                                        </div>
                                    </div>
                                    <h4 class="campaign-two__title">
                                        Formation sur la cyber sécurité à la mairie de Koumassi
                                    </h4>
                                    <div class="progress-box">
                                        <div class="progress-box__bar-text">Raised</div>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="70%"
                                                style="width: 0%;">
                                            </div>
                                        </div>
                                        <div class="progress-box__bar-number count-box">
                                            <span class="count-text" data-stop="70" data-speed="1000">0</span>
                                            <span>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="campaign-two__single">
                                <div class="campaign-two__image">
                                    <img src="assets/images/campaign/campaign-twoImg3.png" alt="">
                                </div>
                                <div class="campaign-two__content">
                                    <div class="cpamign-two__overlay"></div>
                                    <div class="campaign-two__time-remaining">
                                        <div class="time-remaining">
                                            <i class="fa-solid fa-clock"></i>
                                            <span class="time-remaining-desc">275</span>
                                            <span class="time-remaining-name">days Remaining</span>
                                        </div>
                                    </div>
                                    <h4 class="campaign-two__title">
                                        Formation sur la gestion des données à la mairie d'Abobo
                                    </h4>
                                    <div class="progress-box">
                                        <div class="progress-box__bar-text">Raised</div>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="70%"
                                                style="width: 0%;">
                                            </div>
                                        </div>
                                        <div class="progress-box__bar-number count-box">
                                            <span class="count-text" data-stop="70" data-speed="1000">0</span>
                                            <span>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="campaign-two__single">
                                <div class="campaign-two__image">
                                    <img src="assets/images/campaign/campaign-twoImg4.png" alt="">
                                </div>
                                <div class="campaign-two__content">
                                    <div class="cpamign-two__overlay"></div>
                                    <div class="campaign-two__time-remaining">
                                        <div class="time-remaining">
                                            <i class="fa-solid fa-clock"></i>
                                            <span class="time-remaining-desc">275</span>
                                            <span class="time-remaining-name">days Remaining</span>
                                        </div>
                                    </div>
                                    <h4 class="campaign-two__title">
                                        Formation sur la gestion des données à la mairie de Yopougon
                                    </h4>
                                    <div class="progress-box">
                                        <div class="progress-box__bar-text">Raised</div>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="70%"
                                                style="width: 0%;">
                                            </div>
                                        </div>
                                        <div class="progress-box__bar-number count-box">
                                            <span class="count-text" data-stop="70" data-speed="1000">0</span>
                                            <span>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="campaign-two__single">
                                <div class="campaign-two__image">
                                    <img src="assets/images/campaign/campaign-twoImg5.png" alt="">
                                </div>
                                <div class="campaign-two__content">
                                    <div class="cpamign-two__overlay"></div>
                                    <div class="campaign-two__time-remaining">
                                        <div class="time-remaining">
                                            <i class="fa-solid fa-clock"></i>
                                            <span class="time-remaining-desc">275</span>
                                            <span class="time-remaining-name">days Remaining</span>
                                        </div>
                                    </div>
                                    <h4 class="campaign-two__title">
                                        Formation sur la cyber sécurité à la mairie de Yopougon
                                    </h4>
                                    <div class="progress-box">
                                        <div class="progress-box__bar-text">Raised</div>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="70%"
                                                style="width: 0%;">
                                            </div>
                                        </div>
                                        <div class="progress-box__bar-number count-box">
                                            <span class="count-text" data-stop="70" data-speed="1000">0</span>
                                            <span>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="campaign-two__single">
                                <div class="campaign-two__image">
                                    <img src="assets/images/campaign/yopougon-mairie.jpeg" alt="">
                                </div>
                                <div class="campaign-two__content">
                                    <div class="cpamign-two__overlay"></div>
                                    <div class="campaign-two__time-remaining">
                                        <div class="time-remaining">
                                            <i class="fa-solid fa-clock"></i>
                                            <span class="time-remaining-desc">275</span>
                                            <span class="time-remaining-name">days Remaining</span>
                                        </div>
                                    </div>
                                    <h4 class="campaign-two__title">
                                        Formation sur la gestion des données à la mairie de Yopougon
                                    </h4>
                                    <div class="progress-box">
                                        <div class="progress-box__bar-text">Raised</div>
                                        <div class="progress-box__bar">
                                            <div class="progress-box__bar__inner count-bar counted" data-percent="70%"
                                                style="width: 0%;">
                                            </div>
                                        </div>
                                        <div class="progress-box__bar-number count-box">
                                            <span class="count-text" data-stop="70" data-speed="1000">0</span>
                                            <span>%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.campaign-two__wrapper -->
            </div><!-- /.container -->
        </section><!-- /.campaign-two -->
