<section class="main-news news-page section-space-top">
    <div class="container">
        <div class="sec-title">
            <h6 class="text-center sec-title__tagline">
                Nos actualités
            </h6><!-- /.sec-title__tagline -->
            <h2 class="text-center sec-title__title">
                Nos actualités
            </h2>
            <!-- /.sec-title__title -->
        </div><!-- /.sec-title -->
        <div class="main-news__inner">
            <div class="row gutter-y-30">
                @foreach ($news as $new)
                    <div class="col-xl-4 col-lg-4 col-md-6">
                        <div class="main-news__card wow fadeInUp animated" data-wow-duration="1500ms"
                            data-wow-delay="000ms"
                            style="visibility: visible; animation-duration: 1500ms; animation-delay: 0ms; animation-name: fadeInUp;">
                            <div class="main-news__img__wrapper">
                                <div class="main-news__img">
                                    <img src="{{ asset('assets/images/news/newsImg1.png')}}" alt="{{ $new->title }}">
                                    <a href="{{ route('news.show', ['slug' => $new]) }}"
                                        class="main-news__card__img__link"></a>
                                </div>
                                <div class="entry-date">
                                    <span class="date">{{ $new->published_at ? $new->published_at->format('d') : '' }}</span>
                                    <span class="month">{{ $new->published_at ? $new->published_at->format('M') : '' }}</span>
                                </div>
                            </div>
                            <div class="main-news__content">
                                <div class="main-news__content-inner">
                                    <div class="main-news__meta">
                                        <span class="main-news__admin">
                                            <i class="fas fa-user-circle"></i> par {{ $new->author }}
                                        </span>
                                        <span class="main-news__comment">
                                            <i class="fas fa-comments"></i>
                                            {{ $new->comments_count }} Commentaires
                                        </span>
                                    </div>
                                    <h3 class="main-news__title">
                                        <a
                                            href="{{ route('news.show', ['slug' => $new]) }}">{{ $new->title }}</a>
                                    </h3>
                                    <a class="main-news__bottom"
                                        href="{{ route('news.show', ['slug' => $new]) }}">
                                        <span class="main-news__read-more"> Lire Plus </span>
                                        <span class="main-news__arrow">
                                            <i class="fas fa-chevron-right"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div><!-- /.col-lg-4-->
                @endforeach
            </div><!-- /.row-->
        </div><!-- /.main-news__inner-->
    </div><!-- /.container-->
</section>
