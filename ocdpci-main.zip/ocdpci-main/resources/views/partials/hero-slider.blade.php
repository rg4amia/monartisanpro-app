 <section class="hero-slider-one" id="home">
            <div class="hero-slider-one__carousel qizon-owl__carousel qizon-owl__carousel--basic-nav owl-carousel"
                data-owl-options='{
		"loop": true,
        "animateOut": "fadeOut",
        "animateIn": "fadeInRightBig",
		"items": 1,
		"autoplay": true,
		"autoplayTimeout": 7000,
		"smartSpeed": 1000,
		"nav": true,
        "navText": ["<span class=\"icon-left-arrow\"></span>","<span class=\"icon-right-arrow\"></span>"],
		"dots": false,
		"margin": 0
	    }'>
                <div class="item">
                    <div class="hero-slider-one__item">
                        <div class="hero-slider-one__bg"
                            style="background-image: url(assets/images/slider-bg/slide-1.jpeg);">
                        </div>
                        <div class="hero-slider-one__shape">
                            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="mx-auto col-xxl-12 col-xl-10 col-lg-10">
                                    <div class="hero-slider-one__content">
                                        <h5 class="hero-slider-one__subtitle">Office de la communication digitale publique de Côte d'Ivoire</h5>
                                        <h1 class="hero-slider-one__title">
                                         <span>Soignez votre visibilité</span>
                                            <span>digitale</span>
                                            <span class="hero-slider-one__title__overlay-group"> </span>
                                        </h1>
                                        <div class="hero-slider-one__btn">
                                            <a href="" class="qizon-btn qizon-btn__active">
                                                <span>Visitez ici</span>
                                            </a>
                                            <a href="" class="qizon-btn">
                                                <span>Voir plus</span>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.slider-item -->

                <div class="item">
                    <div class="hero-slider-one__item">
                        <div class="hero-slider-one__bg"
                            style="background-image: url(assets/images/slider-bg/slide-2.jpeg);">
                        </div>
                        <div class="hero-slider-one__shape">
                            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="mx-auto col-xxl-12 col-xl-10 col-lg-10">
                                    <div class="hero-slider-one__content">
                                          <h5 class="hero-slider-one__subtitle">Etre visible est beaucoup plus facile!</h5>
                                        <h1 class="hero-slider-one__title">
                                            <span>Rejoignez le voyage</span>
                                            <span>de la communication</span>
                                            <span class="hero-slider-one__title__overlay-group"> </span>
                                        </h1>
                                        <div class="hero-slider-one__btn">
                                            <a href="" class="qizon-btn qizon-btn__active">
                                                <span>Visitez ici</span>
                                            </a>
                                            <a href="" class="qizon-btn">
                                                <span>Voir plus</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.slider-item -->

                <div class="item">
                    <div class="hero-slider-one__item">
                        <div class="hero-slider-one__bg"
                            style="background-image: url(assets/images/slider-bg/slide-3.jpeg);">
                        </div>
                        <div class="hero-slider-one__shape">
                            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="mx-auto col-xxl-12 col-xl-10 col-lg-10 col-sm-12">
                                    <div class="hero-slider-one__content">
                                         <h5 class="hero-slider-one__subtitle">Devenez plus visible!</h5>
                                        <h1 class="hero-slider-one__title">
                                            <span>Devenez visible</span>
                                            <span>au plan national </span>
                                            <span class="hero-slider-one__title__overlay-group"> </span>
                                        </h1>
                                        <div class="hero-slider-one__btn">
                                            <a href="" class="qizon-btn qizon-btn__active">
                                                <span>Visitez ici</span>
                                            </a>
                                            <a href="" class="qizon-btn">
                                                <span>Voir plus</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.slider-item -->

                <div class="item">
                    <div class="hero-slider-one__item">
                        <div class="hero-slider-one__bg"
                            style="background-image: url(assets/images/slider-bg/slide-4.jpeg);">
                        </div>
                        <div class="hero-slider-one__shape">
                            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="mx-auto col-xxl-12 col-xl-10 col-lg-10">
                                    <div class="hero-slider-one__content">
                                        <h5 class="hero-slider-one__subtitle">Office de la communication digitale publique de Côte d'Ivoire</h5>
                                        <h1 class="hero-slider-one__title">
                                         <span>Soignez votre visibilité</span>
                                            <span>digitale</span>
                                            <span class="hero-slider-one__title__overlay-group"> </span>
                                        </h1>
                                        <div class="hero-slider-one__btn">
                                            <a href="" class="qizon-btn qizon-btn__active">
                                                <span>Visitez ici</span>
                                            </a>
                                            <a href="" class="qizon-btn">
                                                <span>Voir plus</span>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.slider-item -->

                <div class="item">
                    <div class="hero-slider-one__item">
                        <div class="hero-slider-one__bg"
                            style="background-image: url(assets/images/slider-bg/slide-5.jpeg);">
                        </div>
                        <div class="hero-slider-one__shape">
                            <img class="hero-slider-shape" src="assets/images/slider-bg/hero-shape.png" alt="">
                        </div>
                        <div class="container">
                            <div class="row">
                                <div class="mx-auto col-xxl-12 col-xl-10 col-lg-10">
                                    <div class="hero-slider-one__content">
                                        <h5 class="hero-slider-one__subtitle">Office de la communication digitale publique de Côte d'Ivoire</h5>
                                        <h1 class="hero-slider-one__title">
                                         <span>Soignez votre visibilité</span>
                                            <span>digitale</span>
                                            <span class="hero-slider-one__title__overlay-group"> </span>
                                        </h1>
                                        <div class="hero-slider-one__btn">
                                            <a href="" class="qizon-btn qizon-btn__active">
                                                <span>Visitez ici</span>
                                            </a>
                                            <a href="" class="qizon-btn">
                                                <span>Voir plus</span>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!-- /.slider-item -->

            </div>
        </section><!-- /.hero-slider-one -->
