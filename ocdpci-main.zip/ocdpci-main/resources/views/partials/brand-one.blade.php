 <section class="brand-one">
     <div class="container">
         <div class="brand-one__wrapper">
             <div class="brand-one__inner">
                 <div class="brand-one__title">
                     <h6 class="brand-one__text">
                         Trusted by over <span>6.000</span> Ambitious <br>
                         Brands Across the US
                     </h6>
                 </div>
                 <div class="brand-one__slider qizon-owl__carousel--basic-nav qizon-owl__carousel owl-carousel"
                     data-owl-options='{
                        "items": 1,
                        "margin": 0,
                        "loop": true,
                        "smartSpeed": 700,
                        "nav": true,
                        "dots": false,
                        "autoplay": false,
                        "responsive": {
                            "0":{
                                "items": 2,
                                "margin": 50
                            },
                            "500":{
                                "items": 3,
                                "margin": 50
                            },
                            "768":{
                                "items": 3,
                                "margin": 40
                            },
                            "992":{
                                "items": 4,
                                "margin": 50
                            },
                            "1200":{
                                "items": 5,
                                "margin": 80
                            }
                        }
                    }'>

                     <div class="item">
                         <div class="brand-one__slider__single">
                             <img src="assets/images/brand/brand-logo.png" alt="">
                         </div><!-- /.brand-one__slider__single-->
                     </div>
                     <div class="item">
                         <div class="brand-one__slider__single">
                             <img src="assets/images/brand/brand-logo.png" alt="">
                         </div><!-- /.brand-one__slider__single-->
                     </div>
                     <div class="item">
                         <div class="brand-one__slider__single">
                             <img src="assets/images/brand/brand-logo.png" alt="">
                         </div><!-- /.brand-one__slider__single-->
                     </div>
                     <div class="item">
                         <div class="brand-one__slider__single">
                             <img src="assets/images/brand/brand-logo.png" alt="">
                         </div><!-- /.brand-one__slider__single-->
                     </div>
                     <div class="item">
                         <div class="brand-one__slider__single">
                             <img src="assets/images/brand/brand-logo.png" alt="">
                         </div><!-- /.brand-one__slider__single-->
                     </div>
                 </div><!-- /.brand-one__slider-->
             </div><!-- /.brand-one__inner-->
         </div><!-- /brand-one__wrapper-->
     </div><!-- /.container-->
 </section><!-- /.brand-one-->
