 <section class="our-beenfit" style="background-image: url(assets/images/beenfits/beenfits-bg.jpg);">
            <div class="container">
                <div class="our-beenfit__wrapper">
                    <div class="beenfit-arrow">
                        <img src="assets/images/beenfits/beenfit-arrow.png" alt="">
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-xl-6 pt-120">
                            <div class="our-beenfit__left">
                                <div class="sec-title wow fadeInDown" data-wow-duration="1500ms">
                                    <h6 class="sec-title__tagline">distinction
                                    </h6><!-- /.sec-title__tagline -->
                                    <h2 class="sec-title__title">
                                        Meilleur presence numérique du trimestre<!-- /.sec-title__title -->
                                </div><!-- /.sec-title -->
                                <div class="our-beenfit__inner">
                                    <div class="our-beenfit__single wow fadeInLeft" data-wow-duration="1500ms"
                                        data-wow-delay="00ms">
                                        <div class="our-beenfit__icon">
                                            <a href="" class="beenfit__icon__icon">
                                                <span class="icon-trusted"></span>
                                            </a>
                                        </div>
                                        <div class="our-beenfit__title">
                                            <h3>Ministère</h3>
                                            <p>
                                                Ministère du numérique
                                            </p>
                                        </div>
                                    </div>
                                    <div class="our-beenfit__single wow fadeInLeft" data-wow-duration="1500ms"
                                        data-wow-delay="200ms">
                                        <div class="our-beenfit__icon">
                                            <a href="" class="beenfit__icon__icon">
                                                <span class="icon-cost-saving"></span>
                                            </a>
                                        </div>
                                        <div class="our-beenfit__title">
                                            <h3>Trafic Mensuel</h3>
                                            <p>200 000 visiteurs</p>
                                        </div>
                                    </div>
                                    <div class="our-beenfit__single wow fadeInLeft" data-wow-duration="1500ms"
                                        data-wow-delay="200ms">
                                        <div class="our-beenfit__icon">
                                            <a href="" class="beenfit__icon__icon">
                                                <span class="icon-cost-saving"></span>
                                            </a>
                                        </div>
                                        <div class="our-beenfit__title">
                                            <h3>Page visitées</h3>
                                            <p>3.36</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.col-lg-5 -->
                        <div class="col-md-6 col-xl-6">
                            <div class="our-beenfit__right wow fadeInRight" data-wow-duration="1500ms">
                                <div class="our-beenfit__img">
                                    <img src="assets/images/beenfits/trophy.jpg" alt="" width="70%">
                                    <div class="trasted wow fadeInDown" data-wow-duration="1500ms"
                                        data-wow-delay="200ms">
                                        <a href="">
                                            <span class="icon-relationship"></span>
                                        </a>
                                        <h5>DISTINCTION</h5>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.col-lg-6 -->
                    </div><!-- /.rowr -->
                </div><!-- /.our-beenfit__wrapper -->
            </div><!-- /.container -->
        </section><!-- /.our-beenfit -->