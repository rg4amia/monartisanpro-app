@use('App\Services\ProjetService', 'ProjetService')
<style>
    .campaign-one__single {
        border: 1px solid #bab9b9;
    }

    .nav-tabs-dark {
        background: #005826;
        border-radius: 100px;
        padding: 8px;
        gap: 8px;
        display: flex;
        justify-content: center;
        border: none;
        width: 100%;
    }

    .nav-tabs-dark .nav-item {
        margin: 0;
    }

    .nav-tabs-dark .nav-link {
        border-radius: 100px;
        padding: 12px 24px;
        color: white;
        border: none;
        transition: background-color 0.3s ease;
    }

    .nav-tabs-dark .nav-link:hover {
        background: #026c30;
        color: white;
    }


    .nav-tabs-dark .nav-link.active {
        background: #026c30;
        color: white;
        border: none;
    }
</style>
<section class="campaign-one section-space-top">
    <div class="container">
        <div class="campaign-one__wrapper">
            <div class="sec-title">
                <h6 class="text-center sec-title__tagline">Vos visite déterminerons chaque positionement
                </h6><!-- /.sec-title__tagline -->
                <h2 class="text-center sec-title__title">Sites les mieux classés</h2>
                <!-- /.sec-title__title -->
            </div><!-- /.sec-title -->
            <div class="campaign-tabs">
                <!-- Main Tabs -->
                <ul class="rounded nav nav-tabs nav-tabs-dark justify-content-center" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="rounded nav-link active" data-bs-toggle="tab" data-bs-target="#secteur-tous"
                            type="button" role="tab">
                            Tous
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#secteur-public"
                            type="button" role="tab">
                            Secteur Public
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#secteur-prive"
                            type="button" role="tab">
                            Secteur Privé
                        </button>
                    </li>
                </ul>

                <!-- Main Tab Content -->
                <div class="tab-content">
                    <!-- Secteur Privé Content -->
                    <div class="tab-pane fade show active" id="secteur-tous" role="tabpanel">
                        <!-- Sub Tabs for Private Sector -->
                        <div class="row pt-30">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover" style="border: 2px solid #026c30;" id="tousTable">
                                    <thead style="background-color: #026c30; color: white;">
                                        <tr>
                                            <th>Classement</th>
                                            <th>Site Web</th>
                                            <th>Catégorie</th>
                                            <th>Chgt de rang</th>
                                            <th>Durée moyenne de la visite</th>
                                            <th>Pages/visite</th>
                                            <th>Taux de rebond</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($data_site_all as $item)
                                            <tr style="transition: background-color 0.3s ease;">
                                                <td style="color: #026c30; font-weight: bold;">
                                                    {{ $item['classement'] }}</td>
                                                <td>
                                                    @if ($item['slug'])
                                                        <img src="{{ asset('assets/images/logo-structure/' . $item['slug'] . '.png') }}"
                                                            alt=""
                                                            style="width: 50px; height: 35px; margin-right: 10px; vertical-align: middle;">
                                                    @endif
                                                    <a href="{{ $item['website'] }}" target="_blank"
                                                        style="color: #ff6600; text-decoration: none;">{{ $item['name'] }}</a>
                                                </td>
                                                <td style="color: #026c30;">{{ ucfirst($item['type']) }}</td>
                                                <td style="color: #ff6600;">-</td>
                                                <td style="color: #026c30;">-</td>
                                                <td style="color: #ff6600;">-</td>
                                                <td style="color: #026c30;">-</td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Ajout de la pagination -->
                        <div class="d-flex justify-content-center">
                            {{--    {{ $data_site_all->links('vendor.pagination.bootstrap-5') }} --}}
                        </div>

                        <div class="text-center">
                            <a href="" class="qizon-btn qizon-btn__active">
                                <span>Voir plus</span>
                            </a>
                        </div>
                    </div>

                    <!-- Secteur Public Content -->
                    <div class="tab-pane fade" id="secteur-public" role="tabpanel">
                        <!-- Sub Tabs for Public Sector -->
                        <ul class="mt-3 rounded nav nav-tabs nav-tabs-dark justify-content-center" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link active" data-bs-toggle="tab"
                                    data-bs-target="#institutions" type="button" role="tab">
                                    Institutions de la République
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#ministeres"
                                    type="button" role="tab">
                                    Ministères
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#districts"
                                    type="button" role="tab">
                                    Districts Autonomes
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#conseils"
                                    type="button" role="tab">
                                    Conseils Régionaux
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#communes"
                                    type="button" role="tab">
                                    Communes
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#ambassades"
                                    type="button" role="tab">
                                    Ambassades de Côte d'Ivoire
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#centrales"
                                    type="button" role="tab">
                                    Centrales Syndicales
                                </button>
                            </li>
                        </ul>

                        <!-- Sub Tab Content for Public Sector -->
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="institutions" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover" id="institutionTable"
                                            style="border: 2px solid #026c30;">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($institutions as $institution)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td>
                                                            @if ($institution->slug)
                                                                <img src="{{ asset('assets/images/logo-structure/' . $institution->slug . '.png') }}"
                                                                    alt=""
                                                                    style="width: 50px; height: 35px; margin-right: 10px; vertical-align: middle;">
                                                            @endif
                                                            <a href="{{ $institution->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $institution->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.institutions') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="ministeres" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="gouvernementsTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($gouvernements as $gouvernement)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $gouvernement->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $gouvernement->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.ministeres') }}" class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="districts" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="districtsTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($districts as $district)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $district->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $district->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.districts') }}" class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="conseils" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="regionsTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($regions as $region)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $region->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $region->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.conseils-regionales') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="communes" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="communesTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($communes as $commune)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $commune->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $commune->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.communes') }}" class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="ambassades" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="ambassadesTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($ambassades as $ambassade)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $ambassade->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $ambassade->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.ambassades') }}" class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="centrales" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($syndicats as $syndicat)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $syndicat->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $syndicat->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.centrale-syndicales') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <!-- Repeat similar structure for other public sector tabs -->
                        </div>
                    </div>

                    <!-- Secteur Privé Content -->
                    <div class="tab-pane fade" id="secteur-prive" role="tabpanel">
                        <!-- Sub Tabs for Private Sector -->
                        <ul class="mt-3 rounded nav nav-tabs nav-tabs-dark justify-content-center" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link active" data-bs-toggle="tab"
                                    data-bs-target="#tres-grandes" type="button" role="tab">
                                    Très Grandes Entreprises
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#grandes"
                                    type="button" role="tab">
                                    Grandes Entreprises
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#moyennes"
                                    type="button" role="tab">
                                    Moyennes Entreprises
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#petites"
                                    type="button" role="tab">
                                    Petites Entreprises
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#groupements"
                                    type="button" role="tab">
                                    Groupements Professionnels
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="rounded nav-link" data-bs-toggle="tab" data-bs-target="#associations"
                                    type="button" role="tab">
                                    Associations Professionnels
                                </button>
                            </li>
                        </ul>

                        <!-- Sub Tab Content for Private Sector -->
                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="tres-grandes" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="tres-grandeTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (ProjetService::tresgrdEntreprises() as $projet)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $projet->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $projet->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.tres-grande-entreprise') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="grandes" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover" id="grandesTable"
                                            style="border: 2px solid #026c30;">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (ProjetService::grdEntreprise() as $projet)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $projet->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $projet->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.grande-entreprise') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="moyennes" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="moyennesTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (ProjetService::mynneEntreprise() as $projet)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $projet->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $projet->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.moyenne-entreprise') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="petites" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="petitesTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (ProjetService::ptEntreprise() as $projet)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $projet->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $projet->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.petite-entreprise') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="groupements" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="groupementsTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (ProjetService::grpementProfessionnel() as $projet)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $projet->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $projet->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.groupements-professionnels') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="associations" role="tabpanel">
                                <!-- Your existing table structure -->
                                <div class="row pt-30">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover"
                                            style="border: 2px solid #026c30;" id="associationsTable">
                                            <thead style="background-color: #026c30; color: white;">
                                                <tr>
                                                    <th>Classement</th>
                                                    <th>Site Web</th>
                                                    <th>Chgt de rang</th>
                                                    <th>Durée moyenne de la visite</th>
                                                    <th>Pages/visite</th>
                                                    <th>Taux de rebond</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach (ProjetService::associations() as $projet)
                                                    <tr style="transition: background-color 0.3s ease;">
                                                        <td style="color: #026c30; font-weight: bold;">-</td>
                                                        <td><a href="{{ $projet->website }}" target="_blank"
                                                                style="color: #ff6600; text-decoration: none;">{{ $projet->name }}</a>
                                                        </td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                        <td style="color: #ff6600;">-</td>
                                                        <td style="color: #026c30;">-</td>
                                                    </tr>
                                                @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div><!-- /.row-->
                                <div class="text-center">
                                    <a href="{{ route('projects.associations-professionnels') }}"
                                        class="qizon-btn qizon-btn__active">
                                        <span>Voir plus</span>
                                    </a>
                                </div>
                            </div>
                            <!-- Repeat similar structure for other private sector tabs -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- /.campaign-one__wrapper -->
</section><!-- /.campaign-one -->
<script>
    document.addEventListener('DOMContentLoaded', function() {
        if (window.DataTable) {
            let tousTable = new DataTable('#tousTable');
            let institutionTable = new DataTable('#institutionTable');
            let gouvernementsTable = new DataTable('#gouvernementsTable');
            let districtsTable = new DataTable('#districtsTable');
            let regionsTable = new DataTable('#regionsTable');
            let communesTable = new DataTable('#communesTable');
            let ambassadesTable = new DataTable('#ambassadesTable');
            let tresgrandeTable = new DataTable('#tres-grandeTable');
            let grandesTable = new DataTable('#grandesTable');
            let moyennesTable = new DataTable('#moyennesTable');
            let petitesTable = new DataTable('#petitesTable');
            let groupementsTable = new DataTable('#groupementsTable');
            let associationsTable = new DataTable('#associationsTable');
            console.log('DataTable initialized');
        } else {
            console.error('DataTables not loaded');
        }
    });
</script>
