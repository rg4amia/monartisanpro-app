   <section class="subscribe">
            <div class="container">
                <div class="subscribe__wrapper">
                    <div class="row gutter-y-30">
                        <div class="col-xl-4 col-lg-4 col-md-6 wow fadeInUp" data-wow-duration="1500ms"
                            data-wow-delay="00ms">
                            <div class="sec-title">
                                <h6 class="sec-title__tagline">subscribe now
                                </h6><!-- /.sec-title__tagline -->
                                <h2 class="sec-title__title">
                                    Get our complete
                                    crowdfunding <br>
                                    guide</h2><!-- /.sec-title__title -->
                            </div><!-- /.sec-title -->
                            <ul class="subscribe__list">
                                <li><i class="fa-solid fa-circle-check"></i>Lorem ipsum dolor sit amet</li>
                                <li><i class="fa-solid fa-circle-check"></i>Sed tempor arcu non ligula convallis</li>
                                <li><i class="fa-solid fa-circle-check"></i>Fusce sodales lacus sollicitudin</li>
                            </ul>
                        </div><!-- /.col-lg-4-->
                        <div class="col-xl-4 col-lg-4 col-md-6 wow fadeInUp" data-wow-duration="1500ms"
                            data-wow-delay="200ms">
                            <div class="subscribe__newsletter">
                                <h5 class="subscribe__text">
                                    Subscribe newsletter to get
                                    our latest updates
                                </h5>
                                <div class="subscribe__form">
                                    <input type="text" placeholder="Email address" class="newsletter__form">
                                    <a href="" class="qizon-btn newsletter__btn">
                                        <span>Subscribe</span>
                                    </a>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                                    <label class="form-check-label" for="flexCheckDefault">
                                        I agree to all terms and policies of
                                        the company
                                    </label>
                                </div>
                            </div>
                        </div><!-- /.col-lg-4-->
                        <div class="col-xl-4 col-lg-4 col-md-12 wow fadeInUp" data-wow-duration="1500ms"
                            data-wow-delay="400ms">
                            <div class="countbar-one">
                                <div class="countbar-one__single">
                                    <a class="countbar-one__icon">
                                        <span class="icon-scrum"></span>
                                    </a>
                                    <div class="countbar-one__number count-box">
                                        <h4 class="count-text" data-stop="690" data-speed="1500">0</h4>
                                        <span>Projects Completed</span>
                                    </div>
                                </div>
                                <div class="countbar-one__single">
                                    <a class="countbar-one__icon">
                                        <span class="icon-mission-2"></span>
                                    </a>
                                    <div class="countbar-one__number count-box">
                                        <h4 class="count-text" data-stop="8600" data-speed="1500">0</h4>
                                        <span>raise till to date</span>
                                    </div>
                                </div>
                                <div class="countbar-one__single">
                                    <a class="countbar-one__icon">
                                        <span class="icon-recommend"></span>
                                    </a>
                                    <div class="countbar-one__number count-box">
                                        <h4 class="count-text" data-stop="362" data-speed="1500"></h4>
                                        <span>happy customers</span>
                                    </div>

                                </div>
                            </div>
                        </div><!-- /.col-lg-4-->
                    </div><!-- /.row-->
                </div><!-- /.subscribe__wrapper-->
            </div><!-- /.container-->
        </section><!-- /.subscribe-->