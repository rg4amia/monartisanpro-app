 <section class="main-gallery">
            <div class="main-gallery__images qizon-owl__carousel owl-carousel wow fadeInUp" data-wow-duration="1500ms"
                data-owl-options='{
                "items": 1,
                "margin": 0,
                "loop": true,
                "autoplay": true,
                "smartSpeed": 700,
                "nav": false,
                "navText": ["<span class=\"icon-arrow-left\"></span>","<span class=\"icon-arrow-right\"></span>"],
                "dots": true,
                "responsive": {
                    "0": {
                        "items": 1,
                        "nav": true,
                        "dots": false,
                        "margin": 10
                    },
                    "361": {
                        "items": 1,
                        "nav": true,
                        "dots": false,
                        "margin": 40
                    },
                    "600": {
                        "items": 2,
                        "margin": 40
                    },
                    "768": {
                        "items": 2,
                        "margin": 20
                    },
                    "800": {
                        "items": 3,
                        "margin": 20
                    },
                    "1200": {
                        "items": 4,
                        "margin": 40
                    },
                    "1440": {
                        "items": 4,
                        "loop": true,
                        "autoplay": false,
                        "dots": true,
                        "margin": 40
                    },
                    "1600": {
                        "items": 5,
                        "loop": false,
                        "autoplay": false,
                        "margin": 0
                    }
                }
            }'>
                <div class="main-gallery__card item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="00ms">
                    <img src="assets/images/gallery/galleryImg1.png" alt="gallery image">
                    <div class="main-gallery__card__hover">
                        <a href="assets/images/gallery/galleryImg1.png" class="img-popup">
                            <span class="main-gallery__card__icon"></span>
                        </a>
                    </div><!-- /.gallery-page__card__hover -->
                </div><!-- /.gallery-page__card -->
                <div class="main-gallery__card item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="200ms">
                    <img src="assets/images/gallery/galleryImg2.png" alt="gallery image">
                    <div class="main-gallery__card__hover">
                        <a href="assets/images/gallery/galleryImg2.png" class="img-popup">
                            <span class="main-gallery__card__icon"></span>
                        </a>
                    </div><!-- /.gallery-page__card__hover -->
                </div><!-- /.gallery-page__card -->
                <div class="main-gallery__card item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="400ms">
                    <img src="assets/images/gallery/galleryImg3.png" alt="gallery image">
                    <div class="main-gallery__card__hover">
                        <a href="assets/images/gallery/galleryImg3.png" class="img-popup">
                            <span class="main-gallery__card__icon"></span>
                        </a>
                    </div><!-- /.gallery-page__card__hover -->
                </div><!-- /.gallery-page__card -->
                <div class="main-gallery__card item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="600ms">
                    <img src="assets/images/gallery/galleryImg4.png" alt="gallery image">
                    <div class="main-gallery__card__hover">
                        <a href="assets/images/gallery/galleryImg4.png" class="img-popup">
                            <span class="main-gallery__card__icon"></span>
                        </a>
                    </div><!-- /.gallery-page__card__hover -->
                </div><!-- /.gallery-page__card -->
                <div class="main-gallery__card item wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="800ms">
                    <img src="assets/images/gallery/galleryImg5.png" alt="gallery image">
                    <div class="main-gallery__card__hover">
                        <a href="assets/images/gallery/galleryImg5.png" class="img-popup">
                            <span class="main-gallery__card__icon"></span>
                        </a>
                    </div><!-- /.gallery-page__card__hover -->
                </div><!-- /.gallery-page__card -->
            </div><!-- /.main-gallery__images -->
        </section><!-- /.main-gallery -->