<section class="content-one">
            <div class="container">
                <div class="content-one__inner wow fadeInUp" data-wow-duration="1500ms">
                    <div class="content-one__single">
                        <div class="content-one__icon-box">
                            <a href="" class="content-one__icon-box__icon">
                                <span class="icon-group"></span>
                            </a>
                            <h4>
                                <span>Marketing</span>
                                <span>Leader</span>
                            </h4>
                        </div>
                        <p class="content-one__box-desc">Lorem ipsum but the majority have alteration in some form, by
                            words look.
                        </p>
                    </div><!-- /.content-one__single-->
                    <div class="content-one__single">
                        <div class="content-one__icon-box">
                            <a href="" class="content-one__icon-box__icon">
                                <span class="icon-campaign"></span>
                            </a>
                            <h4>
                                <span> Start your</span>
                                <span>Campaigns</span>
                            </h4>
                        </div>
                        <p class="content-one__box-desc">Lorem ipsum but the majority have alteration in some form, by
                            words look.
                        </p>
                    </div><!-- /.content-one__single-->
                    <div class="content-one__single">
                        <div class="content-one__icon-box">
                            <a href="" class="content-one__icon-box__icon">
                                <span class="icon-miscellaneous"></span>
                            </a>
                            <h4>
                                <span>Entrepreneur</span>
                                <span>Services</span>
                            </h4>
                        </div>
                        <p class="content-one__box-desc">Lorem ipsum but the majority have alteration in some form, by
                            words look.
                        </p>
                    </div><!-- /.content-one__single-->
                </div><!-- /.content-one__inner-->
            </div><!-- /.container-->
        </section><!-- /.content-one-->
