   <section class="main-cta wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
            <div class="main-cta__shape">
                <img src="assets/images/cta-shape.png" alt="">
                <p class="main-cta__shape__text">Results in <br>
                    few seconds</p>
            </div>
            <div class="container">
                <div class="main-cta__background" style="background-image: url(assets/images/ctabg.png);">
                </div><!-- /.cta-one__background-->
                <div class="main-cta__content">
                    <div class="main-cta__title">
                        <p>Your story starts from here</p>
                        <h3>Ready to raise funds for idea?</h3>
                    </div>
                    <a href="" class="qizon-btn">
                        <span>Make it Happen</span>
                    </a>
                </div><!-- /.cta-one__content-->
            </div><!-- /.container-->
        </section><!-- /.main-cta-one-->