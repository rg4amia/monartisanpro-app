<section class="main-testimonial testimonial--one"
            style="background-image: url(assets/images/testimonial/testimonial-bg-shape.png);">
            <div class="main-testimonial__bg"></div>
            <div class="container">
                <div class="main-testimonial__wrapper">
                    <div class="main-testimonial__left">
                        <div class="sec-title wow fadeInLeft" data-wow-duration="1500ms">
                            <h6 class="sec-title__tagline">testimonials
                            </h6><!-- /.sec-title__tagline -->

                            <h2 class="sec-title__title">
                                What they’re <br>
                                talking about?<!-- /.sec-title__title -->
                        </div><!-- /.sec-title -->
                        <div class="main-testimonial__reviews wow fadeInLeft" data-wow-duration="2000ms">
                            <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                            <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                            <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                            <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>
                            <a href="" class="main-testimonial__star"><i class="fa-solid fa-star"></i></a>

                        </div>
                        <p class="main-testimonial__reviews__text">
                            Trust score 4.5 (Based on 2,500 reviews)
                        </p>
                    </div><!-- /.main-testimonial__left-->
                    <div class="main-testimonial__right qizon-owl__carousel owl-carousel owl-theme wow fadeInRight"
                        data-wow-duration="1500ms" data-owl-options='
                        { "items": 1,
                         "margin": 0,
                         "loop" :true,
                         "smartSpeed": 700,
                          "dots":false,
                          "autoplay":false,
                           "responsive" :  { "0" :

                         {
                            "items" : 1,
                           "margin" : 10
                         },

                         "991" :
                          {
                            "items" : 1,
                            "margin" :10
                        },
                        "992" : {
                            "items" : 1.2,
                            "margin" : 10
                        },
                        "1200" : {
                            "items" : 1.6,
                            "margin" : 30
                        },
                        "1440" : {
                            "items" : 1.9,
                            "margin" : 30
                        }
                    }
                    }'>

                        <div class="item">
                            <div class="main-testimonial__single">
                                <div class="main-testimonial__content">
                                    <div class="main-testimonial__meta">
                                        <div class="main-testimonial__meta-left">
                                            <div class="main-testimonial__image">
                                                <img src="assets/images/testimonial/testimonialImg1.png" alt="">
                                                <span class="main-testimonial__quote-icon">“</span>
                                            </div>
                                        </div>
                                        <div class="main-testimonial__meta-right">
                                            <div class="main-testimonial__stars"> <i class="fa fa-star"></i> <i
                                                    class="fa fa-star"></i> <i class="fa fa-star"></i> <i
                                                    class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                            <h4 class="main-testimonial__name">Kevin martin</h4>
                                            <div class="main-testimonial__job">Crowd Company Founder</div>
                                        </div>
                                    </div>
                                    <div class="main-testimonial__quote"> I tried this smart piano and learned how to
                                        play
                                        music in a day. There are many variations of passages of lorem ipsum but the
                                        majority.</div>
                                </div>
                            </div>
                        </div><!-- /.item-->
                        <div class="item">
                            <div class="main-testimonial__single">
                                <div class="main-testimonial__content">
                                    <div class="main-testimonial__meta">
                                        <div class="main-testimonial__meta-left">
                                            <div class="main-testimonial__image">
                                                <img src="assets/images/testimonial/testimonialImg2.png" alt="">
                                                <span class="main-testimonial__quote-icon">“</span>
                                            </div>
                                        </div>
                                        <div class="main-testimonial__meta-right">
                                            <div class="main-testimonial__stars"> <i class="fa fa-star"></i> <i
                                                    class="fa fa-star"></i> <i class="fa fa-star"></i> <i
                                                    class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                            <h4 class="main-testimonial__name">Jessica brown</h4>
                                            <div class="main-testimonial__job">Crowd Company Founder</div>
                                        </div>
                                    </div>
                                    <div class="main-testimonial__quote"> I tried this smart piano and learned how to
                                        play
                                        music in a day. There are many variations of passages of lorem ipsum but the
                                        majority.</div>
                                </div>
                            </div>
                        </div><!-- /.item-->
                        <div class="item">
                            <div class="main-testimonial__single">
                                <div class="main-testimonial__content">
                                    <div class="main-testimonial__meta">
                                        <div class="main-testimonial__meta-left">
                                            <div class="main-testimonial__image">
                                                <img src="assets/images/testimonial/testimonialImg3.png" alt="">
                                                <span class="main-testimonial__quote-icon">“</span>
                                            </div>
                                        </div>
                                        <div class="main-testimonial__meta-right">
                                            <div class="main-testimonial__stars"> <i class="fa fa-star"></i> <i
                                                    class="fa fa-star"></i> <i class="fa fa-star"></i> <i
                                                    class="fa fa-star"></i> <i class="fa fa-star"></i></div>
                                            <h4 class="main-testimonial__name">Jessica brown</h4>
                                            <div class="main-testimonial__job">Crowd Company Founder</div>
                                        </div>
                                    </div>
                                    <div class="main-testimonial__quote"> I tried this smart piano and learned how to
                                        play
                                        music in a day. There are many variations of passages of lorem ipsum but the
                                        majority.</div>
                                </div>
                            </div>
                        </div><!-- /.item-->
                    </div><!-- /.main-testimonial__right-->
                </div><!-- /.main-testimonial__wrapper-->
            </div><!-- /.container-->
        </section><!-- /.main-testimonial-->