<section class="main-news section-space-top">
            <div class="container">
                <div class="sec-title">
                    <h6 class="text-center sec-title__tagline">From blog posts
                    </h6><!-- /.sec-title__tagline -->
                    <h2 class="text-center sec-title__title"> News & articles</h2><!-- /.sec-title__title -->
                </div><!-- /.sec-title -->
                <div class="main-news__inner">
                    <div class="row gutter-y-30">
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="main-news__card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='000ms'>
                                <div class="main-news__img__wrapper">
                                    <div class="main-news__img">
                                        <img src="assets/images/news/newsImg1.png" alt="">
                                        <a href="News-details.html" class="main-news__card__img__link"></a>
                                    </div>
                                    <div class="entry-date">
                                        <span class="date">28</span>
                                        <span class="month">Feb</span>
                                    </div>
                                </div>
                                <div class="main-news__content">
                                    <div class="main-news__content-inner">
                                        <div class="main-news__meta">
                                            <span class="main-news__admin">
                                                <i class="fas fa-user-circle"></i> by admin
                                            </span>
                                            <span class="main-news__comment">
                                                <i class="fas fa-comments"></i>
                                                2 Comments
                                            </span>

                                        </div>
                                        <h3 class="main-news__title">
                                            <a href="News-details.html"> Money markets rates finding
                                                the best accounts</a>
                                        </h3>
                                        <a class="main-news__bottom" href="News-details.html">
                                            <span class="main-news__read-more"> Read More </span>
                                            <span class="main-news__arrow">
                                                <i class="fas fa-chevron-right"></i>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.col-lg-4-->
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="main-news__card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='200ms'>
                                <div class="main-news__img__wrapper">
                                    <div class="main-news__img">
                                        <img src="assets/images/news/newsImg2.png" alt="">
                                        <a href="News-details.html" class="main-news__card__img__link"></a>
                                    </div>
                                    <div class="entry-date">
                                        <span class="date">28</span>
                                        <span class="month">Feb</span>
                                    </div>
                                </div>
                                <div class="main-news__content">
                                    <div class="main-news__content-inner">
                                        <div class="main-news__meta">
                                            <span class="main-news__admin">
                                                <i class="fas fa-user-circle"></i> by admin
                                            </span>
                                            <span class="main-news__comment">
                                                <i class="fas fa-comments"></i>
                                                2 Comments
                                            </span>

                                        </div>
                                        <h3 class="main-news__title">
                                            <a href="News-details.html"> Money markets rates finding
                                                the best accounts</a>
                                        </h3>
                                        <a class="main-news__bottom" href="news.html">
                                            <span class="main-news__read-more"> Read More </span>
                                            <span class="main-news__arrow">
                                                <i class="fas fa-chevron-right"></i>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.col-lg-4-->
                        <div class="col-xl-4 col-lg-4 col-md-6">
                            <div class="main-news__card wow fadeInUp" data-wow-duration='1500ms' data-wow-delay='400ms'>
                                <div class="main-news__img__wrapper">
                                    <div class="main-news__img">
                                        <img src="assets/images/news/newsImg3.png" alt="">
                                        <a href="News-details.html" class="main-news__card__img__link"></a>
                                    </div>
                                    <div class="entry-date">
                                        <span class="date">28</span>
                                        <span class="month">Feb</span>
                                    </div>
                                </div>
                                <div class="main-news__content">
                                    <div class="main-news__content-inner">
                                        <div class="main-news__meta">
                                            <span class="main-news__admin">
                                                <i class="fas fa-user-circle"></i> by admin
                                            </span>
                                            <span class="main-news__comment">
                                                <i class="fas fa-comments"></i>
                                                2 Comments
                                            </span>

                                        </div>
                                        <h3 class="main-news__title">
                                            <a href="News-details.html">Money markets rates finding
                                                the best accounts</a>
                                        </h3>
                                        <a class="main-news__bottom" href="News-details.html">
                                            <span class="main-news__read-more"> Read More </span>
                                            <span class="main-news__arrow">
                                                <i class="fas fa-chevron-right"></i>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div><!-- /.col-lg-4-->
                    </div><!-- /.row-->
                </div><!-- /.main-news__inner-->
            </div><!-- /.container-->
        </section><!-- /.main-news-->
