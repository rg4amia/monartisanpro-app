@extends('layouts.admin')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-8 d-flex align-items-stretch">
                <div class="card w-100">
                    <div class="card-body p-4">
                        <h5 class="card-title fw-semibold mb-4">Tableau de bord</h5>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="card bg-primary text-white">
                                    <div class="card-body">
                                        <h5 class="card-title">Districts</h5>
                                        <p class="card-text display-5">{{ $stats['districts_count'] }}</p>
                                    </div>
                                </div>
                            </div>
                            <!-- Cartes similaires pour autres entités -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
