@extends('layouts.admin')

@section('content')
    <div class="container-fluid">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title fw-semibold mb-4">Gouvernements</h5>

                <a href="{{ route('gouvernements.create') }}" class="btn btn-primary mb-3">
                    Ajouter un Gouvernement
                </a>

                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif

                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th>Nom</th>
                                <th>Slug</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($gouvernements as $gouvernement)
                                <tr>
                                    <td>{{ $gouvernement->name }}</td>
                                    <td>{{ $gouvernement->slug }}</td>
                                    <td>{{ $gouvernement->email }}</td>
                                    <td>{{ $gouvernement->phone }}</td>
                                    <td>
                                        <a href="{{ route('gouvernements.edit', $gouvernement) }}"
                                            class="btn btn-sm btn-warning">
                                            Éditer
                                        </a>
                                        <form action="{{ route('gouvernements.destroy', $gouvernement) }}" method="POST"
                                            class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-danger"
                                                onclick="return confirm('Êtes-vous sûr ?')">
                                                Supprimer
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{ $gouvernements->links() }}
                </div>
            </div>
        </div>
    </div>
@endsection
